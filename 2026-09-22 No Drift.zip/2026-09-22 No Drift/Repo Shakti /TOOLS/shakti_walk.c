
/* Module: walk_types.h */
#ifndef SHAKTI_WALK_TYPES_H
#define SHAKTI_WALK_TYPES_H
#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#define W_FILES 512
#define W_FUNCS 4096
#define W_ARGS 32
#define W_CALLS 65536
#define W_EFFECTS 65536
#define W_TOKENS 262144
#define W_SOURCE (32UL*1024UL*1024UL)
#define W_GUIDE (64UL*1024UL*1024UL)
#define W_PATH 512
#define W_NAME 128
#define W_TYPE 256
#define W_DECL 2048
typedef struct { char name[W_NAME],type[W_TYPE],decl[W_DECL]; size_t start,end; } w_input;
typedef struct {
    char path[W_PATH],section,subsection,git_sha[41],actual_git_sha[41]; size_t offset,length;
    uint64_t pin; int first,count,syntax_gaps; size_t unparsed_tail;
} w_file;
typedef struct {
    int file; char name[W_NAME],type[W_TYPE],decl[W_DECL];
    size_t start,body,end; uint64_t pin; w_input input[W_ARGS]; int inputs;
    int depth,flow,home,is_static;
} w_function;
typedef struct { int from,to; size_t site,end; char target[W_NAME]; int argc; size_t arg_start[W_ARGS],arg_end[W_ARGS]; } w_call;
typedef struct { int owner; size_t site,end; char kind[24],identity[W_DECL],type[W_TYPE]; } w_effect;
typedef struct {
    char file[W_PATH],name[W_NAME],label[W_NAME],heading[W_PATH],decl[W_DECL];
    char section,subsection; int number,current,declaration_changed; size_t start,end;
} w_home;
typedef struct { size_t start,end; int kind,match; } w_token;
extern w_file wf[W_FILES]; extern int wnfile;
extern w_function wn[W_FUNCS]; extern int wnfunc;
extern w_call wc[W_CALLS]; extern int wncall;
extern w_effect we[W_EFFECTS]; extern int wneffect;
extern w_home wh[W_FUNCS]; extern int wnhome;
extern w_token wt[W_TOKENS]; extern int wntoken;
extern char wsource[W_SOURCE],wguide[W_GUIDE]; extern size_t wsource_len,wguide_len;
extern char wroot[W_PATH],wprevious[W_PATH],wroot_file[W_PATH],wroot_name[W_NAME],wrevision[80];
extern char wtree_path[W_PATH];
extern char wreader_reference[W_PATH];
extern char wsupervision_reference[W_PATH];
extern const char *wchapters[11];
extern char wsections[15][W_PATH],wsubsections[15][26][W_PATH];
extern int wfailure,wunknown,wroot_function;
int w_fail(const char *message,const char *detail);
int w_copy(char *out,size_t cap,const char *in);
int w_read(const char *path,char *buffer,size_t cap,size_t *length);
int w_join(char *out,size_t cap,const char *left,const char *right);
uint64_t w_pin(const char *bytes,size_t n);
void w_git_blob_sha1(const char *bytes,size_t n,char out[41]);
void w_field(FILE *out,const char *s); void w_xml(FILE *out,const char *s);
void w_span(FILE *out,int file,size_t start,size_t end,int xml);
void w_identity(FILE *out,int f); void w_address(FILE *out,int f);
void w_function_xml(FILE *out,int f); int w_output_open(const char *path,FILE **out);
int w_output_close(FILE *out,const char *path); int w_commit_output(const char *path);
int w_load_config(const char *path);
int w_load_tree(const char *path);
int w_admit_file(const char *path);
int w_load_sources(void);
int w_load_homes(void);
int w_scan_all(void);
int w_tokenize(int file);
int w_token_is(int i,const char *s);
int w_tokens_text(int lo,int hi,int omit,char *out,size_t cap);
int w_find(int file,const char *name);
int w_bind_homes(void);
int w_emit_registry(FILE *out);
int w_check_registry(const char *path);
int w_emit_xml(FILE *out,int section);
int w_emit_flags(FILE *out);
int w_inventory(const char *config,const char *registry,const char *xml,const char *flags);
int w_decide(const char *config,const char *registry,const char *output,const char *scope);
int w_generate(const char *config,const char *registry,const char *output);
int w_audit(const char *config,const char *registry,const char *guide);
int w_prepare(const char *config);
int w_render_guide(FILE *out);
int w_equal(FILE *a,FILE *b);
int w_reader_load(void);
void w_reader_records(FILE *out);
void w_reader_key(FILE *out);
void w_reader_tree(FILE *out);
void w_reader_section(FILE *out,int section);
void w_reader_glossary(FILE *out);
void w_reader_link(FILE *out,int home);
int w_document_load(void);
void w_document_records(FILE *out);
void w_document_copy(FILE *out,const char *first,const char *last);
#endif

/* Module: walk_common.c */
#include <string.h>
#include <stdlib.h>
w_file wf[W_FILES]; int wnfile;
w_function wn[W_FUNCS]; int wnfunc;
w_call wc[W_CALLS]; int wncall;
w_effect we[W_EFFECTS]; int wneffect;
w_home wh[W_FUNCS]; int wnhome;
w_token wt[W_TOKENS]; int wntoken;
char wsource[W_SOURCE],wguide[W_GUIDE]; size_t wsource_len,wguide_len;
char wroot[W_PATH],wprevious[W_PATH],wroot_file[W_PATH],wroot_name[W_NAME],wrevision[80];
char wtree_path[W_PATH];
char wreader_reference[W_PATH];
char wsupervision_reference[W_PATH];
char wsections[15][W_PATH],wsubsections[15][26][W_PATH];
int wfailure,wunknown,wroot_function=-1;
int w_fail(const char *message,const char *detail)
{ fprintf(stderr,"REFUSE|%s|%s\n",message,detail?detail:"");wfailure=1;return 1; }
int w_copy(char *out,size_t cap,const char *in)
{ size_t n=strlen(in);if(n>=cap)return w_fail("text_capacity",in);memcpy(out,in,n+1);return 0; }
int w_read(const char *path,char *buffer,size_t cap,size_t *length)
{
    FILE *in;size_t n;
    if(cap<2)return w_fail("file_capacity",path);
    in=fopen(path,"rb");
    if(!in)return w_fail("cannot_read",path);
    n=fread(buffer,1,cap-1,in);
    if(ferror(in)||fgetc(in)!=EOF){fclose(in);return w_fail("file_capacity_or_read",path);}
    if(fclose(in))return w_fail("close_input",path);
    if(memchr(buffer,0,n))return w_fail("nul_in_text",path);
    buffer[n]=0;*length=n;return 0;
}
int w_join(char *out,size_t cap,const char *left,const char *right)
{
    int n;
    if(right[0]=='/')return w_copy(out,cap,right);
    n=snprintf(out,cap,"%s/%s",left,right);
    return n<0||(size_t)n>=cap?w_fail("path_capacity",right):0;
}
uint64_t w_pin(const char *bytes,size_t n)
{ uint64_t h=UINT64_C(14695981039346656037);size_t i;for(i=0;i<n;++i){h^=(unsigned char)bytes[i];h*=UINT64_C(1099511628211);}return h; }
void w_field(FILE *out,const char *s)
{ for(;*s;++s){unsigned c=(unsigned char)*s;if(c=='%'||c=='|'||c==','||c=='\n'||c=='\r'||c<32)fprintf(out,"%%%02X",c);else fputc((int)c,out);} }
void w_xml(FILE *out,const char *s)
{ for(;*s;++s)switch(*s){case '&':fputs("&amp;",out);break;case '<':fputs("&lt;",out);break;case '>':fputs("&gt;",out);break;case '"':fputs("&quot;",out);break;default:fputc((unsigned char)*s,out);} }
int w_admit_file(const char *path)
{
    int i;
    if(wnfile==W_FILES)return w_fail("file_capacity",path);
    if(!*path||*path=='/'||strstr(path,"..")||strchr(path,'\\'))return w_fail("relative_source_path",path);
    for(i=0;i<wnfile;++i)if(!strcmp(wf[i].path,path))return w_fail("duplicate_file",path);
    return w_copy(wf[wnfile++].path,W_PATH,path);
}
int w_load_config(const char *path)
{
    FILE *in=fopen(path,"rb");char line[4096];int seen=0;
    if(!in)return w_fail("cannot_read_config",path);
    while(fgets(line,sizeof line,in)){
        char *p;size_t n=strlen(line);
        if(!n||line[n-1]!='\n'){fclose(in);return w_fail("config_line_requires_newline",path);}
        while(n&&(line[n-1]=='\n'||line[n-1]=='\r'))line[--n]=0;
        if(!n||line[0]=='#')continue;
        p=strchr(line,'=');if(!p){fclose(in);return w_fail("config_key_value",line);}*p++=0;
        if(!strcmp(line,"file")){
            fclose(in);return w_fail("hand_selected_inventory_refused_use_repository_tree",path);
        }else{
            char *target=NULL;size_t cap=0;int bit=0;
            if(!strcmp(line,"source_root")){target=wroot;cap=sizeof wroot;bit=1;}
            if(!strcmp(line,"previous_guide")){target=wprevious;cap=sizeof wprevious;bit=2;}
            if(!strcmp(line,"root_file")){target=wroot_file;cap=sizeof wroot_file;bit=4;}
            if(!strcmp(line,"root_name")){target=wroot_name;cap=sizeof wroot_name;bit=8;}
            if(!strcmp(line,"source_revision")){target=wrevision;cap=sizeof wrevision;bit=16;}
            if(!strcmp(line,"repository_tree")){target=wtree_path;cap=sizeof wtree_path;bit=32;}
            if(!strcmp(line,"reader_reference")){target=wreader_reference;cap=sizeof wreader_reference;bit=64;}
            if(!strcmp(line,"supervision_reference")){target=wsupervision_reference;cap=sizeof wsupervision_reference;bit=128;}
            if(!target||(seen&bit)||!*p||w_copy(target,cap,p)){fclose(in);return w_fail("invalid_config_key",line);}seen|=bit;
        }
    }
    if(ferror(in)||fclose(in))return w_fail("config_read",path);
    if((seen&63)!=63)return w_fail("missing_config_field",path);
    if(w_load_tree(wtree_path))return 1;
    if(!wnfile)return w_fail("empty_source_inventory",path);
    {int i,j;for(i=1;i<wnfile;++i)for(j=i;j>0&&strcmp(wf[j-1].path,wf[j].path)>0;--j){w_file t=wf[j];wf[j]=wf[j-1];wf[j-1]=t;}}
    return 0;
}
int w_load_sources(void)
{
    int i;char path[W_PATH*2];
    for(i=0;i<wnfile;++i){size_t n;
        if(w_join(path,sizeof path,wroot,wf[i].path)||w_read(path,wsource+wsource_len,W_SOURCE-wsource_len,&n))return 1;
        wf[i].offset=wsource_len;wf[i].length=n;wf[i].pin=w_pin(wsource+wsource_len,n);wsource_len+=n+1;
        w_git_blob_sha1(wsource+wf[i].offset,n,wf[i].actual_git_sha);
    }return 0;
}
int w_find(int file,const char *name)
{ int i;for(i=0;i<wnfunc;++i)if(wn[i].file==file&&!strcmp(wn[i].name,name))return i;return -1; }
int w_equal(FILE *a,FILE *b)
{
    unsigned char aa[8192],bb[8192];size_t na,nb;
    do{na=fread(aa,1,sizeof aa,a);nb=fread(bb,1,sizeof bb,b);if(na!=nb||memcmp(aa,bb,na))return 0;}while(na);
    return !ferror(a)&&!ferror(b);
}
int w_prepare(const char *config)
{ return w_load_config(config)||w_load_sources()||w_scan_all()||w_load_homes()||w_bind_homes()||w_reader_load()||w_document_load(); }

/* Module: walk_tree.c */
#include <string.h>
#include <ctype.h>

/* Read the complete Git tree response as data. No repository or command
 * execution is part of the native program. All tracked .c/.h blobs are
 * admitted, including unreachable tools and tests. */
static char json[4UL*1024UL*1024UL];
static const char *cursor;
static void space(void){while(isspace((unsigned char)*cursor))++cursor;}
static int mark(char c){space();if(*cursor!=c)return w_fail("tree_json_token","");++cursor;return 0;}
static int string(char *out,size_t cap)
{
    size_t n=0;if(mark('"'))return 1;
    while(*cursor&&*cursor!='"'){unsigned char c=(unsigned char)*cursor++;
        if(c=='\\'){
            c=(unsigned char)*cursor++;
            switch(c){case '"':case '\\':case '/':break;
            case 'b':c='\b';break;case 'f':c='\f';break;case 'n':c='\n';break;case 'r':c='\r';break;case 't':c='\t';break;
            default:return w_fail("tree_json_escape_unsupported","");}
        }else if(c<32)return w_fail("tree_json_control","");
        if(n+1>=cap)return w_fail("tree_json_string_capacity","");
        out[n++]=(char)c;
    }
    if(*cursor!='"')return w_fail("tree_json_string_end","");
    ++cursor;out[n]=0;return 0;
}
static int skip(int depth)
{
    char value[W_PATH*4];space();if(depth>8)return w_fail("tree_json_depth","");
    if(*cursor=='"')return string(value,sizeof value);
    if(*cursor=='{'||*cursor=='['){char close=*cursor++=='{'?'}':']';
        for(;;){space();if(*cursor==close){++cursor;return 0;}
            if(skip(depth+1))return 1;
            space();if(*cursor==':'||*cursor==','){++cursor;continue;}
            if(*cursor!=close)return w_fail("tree_json_separator","");
        }
    }
    if(!strncmp(cursor,"false",5)){cursor+=5;return 0;}
    if(!strncmp(cursor,"true",4)||!strncmp(cursor,"null",4)){cursor+=4;return 0;}
    if(*cursor=='-')++cursor;
    if(!isdigit((unsigned char)*cursor))return w_fail("tree_json_value","");
    while(isdigit((unsigned char)*cursor)||*cursor=='.'||*cursor=='e'||*cursor=='E'||*cursor=='+'||*cursor=='-')++cursor;
    return 0;
}
static int entry(void)
{
    char key[128],path[W_PATH]="",type[32]="",mode[16]="",sha[41]="";int seen=0;
    if(mark('{'))return 1;
    for(;;){space();if(*cursor=='}'){++cursor;break;}
        if(string(key,sizeof key)||mark(':'))return 1;
        if(!strcmp(key,"path")){if(seen&1)return w_fail("tree_duplicate_path_key","");seen|=1;if(string(path,sizeof path))return 1;}
        else if(!strcmp(key,"type")){if(seen&2)return w_fail("tree_duplicate_type_key","");seen|=2;if(string(type,sizeof type))return 1;}
        else if(!strcmp(key,"mode")){if(seen&4)return w_fail("tree_duplicate_mode_key","");seen|=4;if(string(mode,sizeof mode))return 1;}
        else if(!strcmp(key,"sha")){if(seen&8)return w_fail("tree_duplicate_sha_key","");seen|=8;if(string(sha,sizeof sha))return 1;}
        else if(skip(0))return 1;
        space();if(*cursor==','){++cursor;continue;}if(*cursor!='}')return w_fail("tree_entry_separator","");
    }
    if(seen!=15||!*path||strlen(sha)!=40)return w_fail("tree_entry_fields","");
    {int i;for(i=0;i<40;++i)if(!((sha[i]>='0'&&sha[i]<='9')||(sha[i]>='a'&&sha[i]<='f')))return w_fail("tree_blob_sha_format",path);}
    {size_t n=strlen(path);
        if(n>=2&&path[n-2]=='.'&&(path[n-1]=='c'||path[n-1]=='h')){
            if(strcmp(type,"blob")||(strcmp(mode,"100644")&&strcmp(mode,"100755")))return w_fail("source_tree_entry_not_regular_blob",path);
            if(w_admit_file(path))return 1;
            if(w_copy(wf[wnfile-1].git_sha,41,sha))return 1;
        }
    }return 0;
}
int w_load_tree(const char *path)
{
    size_t length;int seen=0;char key[128];
    if(w_read(path,json,sizeof json,&length))return 1;
    cursor=json;if(mark('{'))return 1;
    for(;;){space();if(*cursor=='}'){++cursor;break;}
        if(string(key,sizeof key)||mark(':'))return 1;
        if(!strcmp(key,"tree")){
            if(seen&1)return w_fail("duplicate_tree","");
            seen|=1;
            if(mark('['))return 1;
            for(;;){space();if(*cursor==']'){++cursor;break;}
                if(entry())return 1;
                space();if(*cursor==','){++cursor;continue;}if(*cursor!=']')return w_fail("tree_array_separator","");
            }
        }else if(!strcmp(key,"truncated")){
            if(seen&2)return w_fail("duplicate_truncated","");
            seen|=2;space();
            if(strncmp(cursor,"false",5))return w_fail("repository_tree_truncated",path);
            cursor+=5;
        }else if(skip(0))return 1;
        space();if(*cursor==','){++cursor;continue;}if(*cursor!='}')return w_fail("tree_root_separator","");
    }
    space();if(*cursor||seen!=3||!wnfile)return w_fail("incomplete_repository_tree",path);
    return 0;
}

/* Module: walk_hash.c */
#include <string.h>
#include <inttypes.h>

typedef struct {uint32_t h[5];unsigned char block[64];size_t used;uint64_t total;} sha1_state;
static uint32_t rol(uint32_t x,unsigned n){return (x<<n)|(x>>(32U-n));}
static void transform(sha1_state *s)
{
    uint32_t words[80],a,b,c,d,e;unsigned i;
    for(i=0;i<16;++i)words[i]=((uint32_t)s->block[i*4]<<24)|((uint32_t)s->block[i*4+1]<<16)|((uint32_t)s->block[i*4+2]<<8)|s->block[i*4+3];
    for(i=16;i<80;++i)words[i]=rol(words[i-3]^words[i-8]^words[i-14]^words[i-16],1);
    a=s->h[0];b=s->h[1];c=s->h[2];d=s->h[3];e=s->h[4];
    for(i=0;i<80;++i){uint32_t f,k,t;
        if(i<20){f=(b&c)|((~b)&d);k=UINT32_C(0x5a827999);}
        else if(i<40){f=b^c^d;k=UINT32_C(0x6ed9eba1);}
        else if(i<60){f=(b&c)|(b&d)|(c&d);k=UINT32_C(0x8f1bbcdc);}
        else{f=b^c^d;k=UINT32_C(0xca62c1d6);}
        t=rol(a,5)+f+e+k+words[i];e=d;d=c;c=rol(b,30);b=a;a=t;
    }
    s->h[0]+=a;s->h[1]+=b;s->h[2]+=c;s->h[3]+=d;s->h[4]+=e;s->used=0;
}
static void octet(sha1_state *s,unsigned char c)
{s->block[s->used++]=c;++s->total;if(s->used==64)transform(s);}
void w_git_blob_sha1(const char *bytes,size_t n,char out[41])
{
    sha1_state s;char header[64];size_t i;uint64_t bits;int j;
    memset(&s,0,sizeof s);s.h[0]=UINT32_C(0x67452301);s.h[1]=UINT32_C(0xefcdab89);s.h[2]=UINT32_C(0x98badcfe);s.h[3]=UINT32_C(0x10325476);s.h[4]=UINT32_C(0xc3d2e1f0);
    (void)snprintf(header,sizeof header,"blob %lu",(unsigned long)n);
    for(i=0;i<=strlen(header);++i)octet(&s,(unsigned char)header[i]);
    for(i=0;i<n;++i)octet(&s,(unsigned char)bytes[i]);
    bits=s.total*8;octet(&s,128);
    while(s.used!=56)octet(&s,0);
    for(j=7;j>=0;--j)octet(&s,(unsigned char)(bits>>(j*8)));
    for(j=0;j<5;++j)(void)snprintf(out+j*8,9,"%08" PRIx32,s.h[j]);
}

/* Module: walk_scan.c */
#include <string.h>
#include <ctype.h>

/* Offsets are zero-based bytes, end exclusive, in the original source file.
 * This scanner inventories source syntax in every conditional branch. It does
 * not silently substitute a preprocessed translation unit for original bytes. */
static int token_file;
static int stack[W_TOKENS];
static int body_lo[W_FUNCS],body_hi[W_FUNCS];
static int queue[W_FUNCS];
static int alpha(unsigned char c){return isalpha(c)||c=='_';}
static int alnum(unsigned char c){return isalnum(c)||c=='_';}
static int token(int kind,size_t a,size_t b)
{
    if(wntoken==W_TOKENS)return w_fail("token_capacity",wf[token_file].path);
    wt[wntoken].kind=kind;wt[wntoken].start=a;wt[wntoken].end=b;
    wt[wntoken++].match=-1;return 0;
}
int w_token_is(int i,const char *s)
{
    size_t n=strlen(s);
    return i>=0&&i<wntoken&&wt[i].end-wt[i].start==n&&
        !memcmp(wsource+wf[token_file].offset+wt[i].start,s,n);
}
int w_tokens_text(int lo,int hi,int omit,char *out,size_t cap)
{
    size_t n=0;int i;
    for(i=lo;i<hi;++i){size_t k=wt[i].end-wt[i].start;
        if(i==omit)continue;
        if(n+k+2>cap)return w_fail("declaration_capacity",wf[token_file].path);
        if(n)out[n++]=' ';
        memcpy(out+n,wsource+wf[token_file].offset+wt[i].start,k);n+=k;
    }out[n]=0;return 0;
}
int w_tokenize(int file)
{
    const char *s=wsource+wf[file].offset;size_t i=0,n=wf[file].length;
    int top=0,line_start=1;token_file=file;wntoken=0;
    while(i<n){size_t a=i;unsigned char c=(unsigned char)s[i];
        if(isspace(c)){if(c=='\n')line_start=1;++i;continue;}
        if(line_start&&c=='#'){
            do {while(i<n&&s[i]!='\n')++i;
                if(i==n)break;
                if(i>0&&s[i-1]=='\\'){++i;continue;}
                ++i;break;
            }while(i<n);continue;
        }
        if(c=='/'&&i+1<n&&s[i+1]=='/'){
            while(i<n&&s[i]!='\n')++i;
            continue;
        }
        if(c=='/'&&i+1<n&&s[i+1]=='*'){
            i+=2;while(i+1<n&&!(s[i]=='*'&&s[i+1]=='/'))++i;
            if(i+1>=n)return w_fail("unterminated_comment",wf[file].path);
            i+=2;continue;
        }
        line_start=0;
        if(c=='"'||c=='\''){
            unsigned char quote=c;int closed=0;++i;
            while(i<n){if(s[i]=='\\'){i+=2;continue;}
                if((unsigned char)s[i++]==quote){closed=1;break;}}
            if(!closed||i>n){
                if(!top){wf[file].unparsed_tail=a;return 0;}
                return w_fail("unterminated_literal",wf[file].path);
            }
            if(token(3,a,i))return 1;
            continue;
        }
        if(alpha(c)){while(i<n&&alnum((unsigned char)s[i]))++i;
            if(token(1,a,i))return 1;
            continue;
        }
        if(isdigit(c)){while(i<n&&(alnum((unsigned char)s[i])||s[i]=='.'))++i;
            if(token(2,a,i))return 1;
            continue;
        }
        ++i;
        if(i<n&&((c=='-'&&s[i]=='>')||(c=='+'&&(s[i]=='+'||s[i]=='='))||
            (c=='-'&&(s[i]=='-'||s[i]=='='))||((c=='='||c=='!'||c=='*'||c=='/'||c=='%'||c=='^')&&s[i]=='=')||
            ((c=='&'||c=='|'||c=='<'||c=='>')&&(s[i]==(char)c||s[i]=='=')))){
            ++i;if(i<n&&s[i]=='='&&(c=='<'||c=='>'))++i;
        }else if(c=='.'&&i+1<n&&s[i]=='.'&&s[i+1]=='.')i+=2;
        if(token(0,a,i))return 1;
        if(c=='('||c=='['||c=='{')stack[top++]=wntoken-1;
        if(c==')'||c==']'||c=='}'){
            int j;char want=c==')'?'(':c==']'?'[':'{';
            if(!top){
                if(c=='}'){++wf[file].syntax_gaps;continue;}
                return w_fail("unmatched_close",wf[file].path);
            }
            j=stack[--top];
            if(s[wt[j].start]!=want)return w_fail("mismatched_delimiter",wf[file].path);
            wt[j].match=wntoken-1;wt[wntoken-1].match=j;
        }
    }
    if(top)return w_fail("unmatched_open",wf[file].path);
    return 0;
}
static int qualifier(int t)
{
    return w_token_is(t,"const")||w_token_is(t,"volatile")||w_token_is(t,"restrict")||
        w_token_is(t,"unsigned")||w_token_is(t,"signed")||w_token_is(t,"long")||
        w_token_is(t,"short")||w_token_is(t,"int")||w_token_is(t,"char")||
        w_token_is(t,"void")||w_token_is(t,"float")||w_token_is(t,"double")||
        w_token_is(t,"_Bool")||w_token_is(t,"struct")||w_token_is(t,"union")||w_token_is(t,"enum");
}
static int input(w_function *f,int lo,int hi)
{
    w_input *a;int i,name=-1;
    if(lo==hi||(hi==lo+1&&w_token_is(lo,"void")))return 0;
    if(f->inputs==W_ARGS)return w_fail("input_capacity",f->name);
    a=&f->input[f->inputs++];
    for(i=lo;i+2<hi;++i)if(w_token_is(i,"(")&&w_token_is(i+1,"*")&&wt[i+2].kind==1){name=i+2;break;}
    if(name<0){
        for(i=lo;i<hi;++i){
            if(w_token_is(i,"[")||w_token_is(i,"("))break;
            if(wt[i].kind==1&&!qualifier(i))name=i;
        }
        if(name==lo)name=-1;
    }
    if(w_token_is(lo,"...")){
        if(w_copy(a->name,sizeof a->name,"variadic"))return 1;
    }else if(name<0)return w_fail("input_name_unresolved",f->name);
    else if(w_tokens_text(name,name+1,-1,a->name,sizeof a->name))return 1;
    a->start=wt[lo].start;a->end=wt[hi-1].end;
    return w_tokens_text(lo,hi,-1,a->decl,sizeof a->decl)||
        w_tokens_text(lo,hi,name,a->type,sizeof a->type);
}
static int definition(int file,int lo,int brace)
{
    int close=brace-1,open=wt[close].match,name=open-1,i,part,type_lo=lo;
    w_function *f;
    if(name<lo||wt[name].kind!=1)return w_fail("function_declarator_unresolved",wf[file].path);
    if(wnfunc==W_FUNCS)return w_fail("function_capacity",wf[file].path);
    f=&wn[wnfunc];f->file=file;f->depth=-1;f->flow=-1;f->home=-1;
    if(w_tokens_text(name,name+1,-1,f->name,sizeof f->name))return 1;
    if(w_find(file,f->name)>=0)return w_fail("duplicate_source_identity",f->name);
    for(i=lo;i<name;++i)if(w_token_is(i,"static"))f->is_static=1;
    while(type_lo<name&&(w_token_is(type_lo,"static")||w_token_is(type_lo,"extern")||w_token_is(type_lo,"inline")))++type_lo;
    if(w_tokens_text(type_lo,name,-1,f->type,sizeof f->type)||
        w_tokens_text(lo,brace,-1,f->decl,sizeof f->decl))return 1;
    if(!f->type[0])return w_fail("return_type_empty",f->name);
    f->start=wt[lo].start;f->body=wt[brace].start;f->end=wt[wt[brace].match].end;
    f->pin=w_pin(wsource+wf[file].offset+f->start,f->end-f->start);
    part=open+1;
    for(i=part;i<close;++i){
        if(w_token_is(i,"(")||w_token_is(i,"[")){i=wt[i].match;continue;}
        if(w_token_is(i,",")){if(input(f,part,i))return 1;part=i+1;}
    }
    if(input(f,part,close))return 1;
    body_lo[wnfunc]=brace+1;body_hi[wnfunc]=wt[brace].match;++wnfunc;++wf[file].count;
    return 0;
}
static int not_call(int i)
{
    return w_token_is(i,"if")||w_token_is(i,"for")||w_token_is(i,"while")||
        w_token_is(i,"switch")||w_token_is(i,"sizeof")||w_token_is(i,"_Alignof")||
        w_token_is(i,"return");
}
static int add_effect(int owner,int lo,int hi,const char *kind)
{
    w_effect *e;
    if(wneffect==W_EFFECTS)return w_fail("effect_capacity",wn[owner].name);
    e=&we[wneffect++];e->owner=owner;e->site=wt[lo].start;e->end=wt[hi-1].end;
    if(w_copy(e->kind,sizeof e->kind,kind)||w_copy(e->type,sizeof e->type,"unresolved"))return 1;
    return w_tokens_text(lo,hi,-1,e->identity,sizeof e->identity);
}
static int scan_body(int owner)
{
    int i,lo=body_lo[owner],hi=body_hi[owner];
    for(i=lo;i<hi;++i){
        if(wt[i].kind==1&&i+1<hi&&w_token_is(i+1,"(")&&!not_call(i)){
            w_call *c;int j,part=i+2,end=wt[i+1].match,argc=0;
            if(wncall==W_CALLS)return w_fail("call_capacity",wn[owner].name);
            if(end<0||end>=hi)return w_fail("call_span",wn[owner].name);
            c=&wc[wncall++];c->from=owner;c->to=-1;c->site=wt[i].start;c->end=wt[end].end;
            if(w_tokens_text(i,i+1,-1,c->target,sizeof c->target))return 1;
            if(i>lo&&(w_token_is(i-1,".")||w_token_is(i-1,"->")))c->to=-2;
            for(j=i+2;j<end;++j){
                if(w_token_is(j,"(")||w_token_is(j,"[")||w_token_is(j,"{")){j=wt[j].match;continue;}
                if(w_token_is(j,",")){
                    if(argc==W_ARGS)return w_fail("call_argument_capacity",c->target);
                    c->arg_start[argc]=wt[part].start;c->arg_end[argc++]=wt[j-1].end;part=j+1;
                }
            }
            if(part<end){
                if(argc==W_ARGS)return w_fail("call_argument_capacity",c->target);
                c->arg_start[argc]=wt[part].start;c->arg_end[argc++]=wt[end-1].end;
            }
            c->argc=argc;
        }
        if((w_token_is(i,")")||w_token_is(i,"]"))&&i+1<hi&&w_token_is(i+1,"(")){
            int start=wt[i].match,part=i+2,j,end=wt[i+1].match,argc=0;w_call *c;
            if(w_token_is(i,"]"))--start;
            if(start<lo)continue;
            if(wncall==W_CALLS)return w_fail("call_capacity",wn[owner].name);
            c=&wc[wncall++];c->from=owner;c->to=-2;c->site=wt[start].start;c->end=wt[end].end;
            if(w_copy(c->target,sizeof c->target,"indirect_expression"))return 1;
            for(j=part;j<end;++j){
                if(w_token_is(j,"(")||w_token_is(j,"[")||w_token_is(j,"{")){j=wt[j].match;continue;}
                if(w_token_is(j,",")){
                    if(argc==W_ARGS)return w_fail("indirect_argument_capacity","");
                    c->arg_start[argc]=wt[part].start;c->arg_end[argc++]=wt[j-1].end;part=j+1;
                }
            }
            if(part<end){
                if(argc==W_ARGS)return w_fail("indirect_argument_capacity","");
                c->arg_start[argc]=wt[part].start;c->arg_end[argc++]=wt[end-1].end;
            }c->argc=argc;
        }
        if(w_token_is(i,"return")){
            int j=i+1;while(j<hi&&!w_token_is(j,";"))++j;
            if(j==hi)return w_fail("return_terminator",wn[owner].name);
            if(add_effect(owner,i,j+1,"return_site"))return 1;
            if(w_copy(we[wneffect-1].type,W_TYPE,wn[owner].type))return 1;
        }
        if(w_token_is(i,"=")||w_token_is(i,"+=")||w_token_is(i,"-=")||
            w_token_is(i,"*=")||w_token_is(i,"/=")||w_token_is(i,"%=")||
            w_token_is(i,"&=")||w_token_is(i,"|=")||w_token_is(i,"^=")||
            w_token_is(i,"<<=")||w_token_is(i,">>=")||w_token_is(i,"++")||w_token_is(i,"--")){
            int a=i,b=i+1;
            if((w_token_is(i,"++")||w_token_is(i,"--"))&&i+1<hi&&wt[i+1].kind==1){
                b=i+2;while(b<hi&&(w_token_is(b,"[")||w_token_is(b,".")||w_token_is(b,"->"))){
                    if(w_token_is(b,"["))b=wt[b].match+1;else b+=2;
                }
            }else{
                a=i-1;
                for(;;){
                    if(a>=lo&&w_token_is(a,"]")){a=wt[a].match-1;continue;}
                    if(a>=lo&&w_token_is(a,")"))a=wt[a].match;
                    if(a>lo&&(w_token_is(a-1,".")||w_token_is(a-1,"->"))){a-=2;continue;}
                    break;
                }
                while(a>lo&&w_token_is(a-1,"*"))--a;
                if(a<lo)a=i;
            }
            if(add_effect(owner,a,b,"write_site"))return 1;
        }
    }return 0;
}
int w_scan_all(void)
{
    int file,i,j;
    for(file=0;file<wnfile;++file){int lo=0;
        wf[file].first=wnfunc;
        if(w_tokenize(file))return 1;
        for(i=0;i<wntoken;++i){
            if(w_token_is(i,";")){lo=i+1;continue;}
            if(w_token_is(i,"{")){
                int k,assignment=0;
                for(k=lo;k<i;++k)if(w_token_is(k,"="))assignment=1;
                if(i>lo&&w_token_is(i-1,")")&&!assignment){if(definition(file,lo,i))return 1;}
                i=wt[i].match;lo=i+1;
            }
        }
        if(lo<wntoken)wf[file].unparsed_tail=wt[lo].start;
        for(i=wf[file].first;i<wnfunc;++i)if(scan_body(i))return 1;
    }
    for(i=0;i<wncall;++i){int found=-1,count=0;
        for(j=0;j<wn[wc[i].from].inputs;++j)if(!strcmp(wn[wc[i].from].input[j].name,wc[i].target))wc[i].to=-2;
        if(wc[i].to==-2){++wunknown;continue;}
        found=w_find(wn[wc[i].from].file,wc[i].target);
        if(found<0){
            for(j=0;j<wnfunc;++j)if(!wn[j].is_static&&!strcmp(wn[j].name,wc[i].target)){found=j;++count;}
            if(count!=1)found=-1;
        }
        wc[i].to=found;if(found<0)++wunknown;
    }
    for(i=0;i<wnfunc;++i)if(!strcmp(wf[wn[i].file].path,wroot_file)&&!strcmp(wn[i].name,wroot_name))wroot_function=i;
    if(wroot_function<0)return w_fail("root_function_missing",wroot_name);
    {int head=0,tail=0,flow=0;queue[tail++]=wroot_function;wn[wroot_function].depth=0;
        while(head<tail){int f=queue[head++];wn[f].flow=flow++;
            for(i=0;i<wncall;++i)if(wc[i].from==f&&wc[i].to>=0&&wn[wc[i].to].depth<0){
                wn[wc[i].to].depth=wn[f].depth+1;queue[tail++]=wc[i].to;
            }
        }
        for(i=0;i<wnfunc;++i)if(wn[i].flow<0)wn[i].flow=flow++;
    }
    return 0;
}

/* Module: walk_homes.c */
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

static int bounded(const char *a,const char *b,char *out,size_t cap)
{ size_t n=(size_t)(b-a);if(n>=cap)return w_fail("prior_field_capacity","");memcpy(out,a,n);out[n]=0;return 0; }
static int field(const char *a,const char *end,const char *tag,char *out,size_t cap)
{
    char open[80],close[80];const char *p,*q;
    if(snprintf(open,sizeof open,"<%s>",tag)<0||snprintf(close,sizeof close,"</%s>",tag)<0)return 1;
    p=strstr(a,open);if(!p||p>=end)return w_fail("prior_field_missing",tag);p+=strlen(open);
    q=strstr(p,close);if(!q||q>end)return w_fail("prior_field_unclosed",tag);
    return bounded(p,q,out,cap);
}
static int finish_home(int h,size_t end)
{
    char decl[W_DECL],expected[16],actual[24];char *p,*q;const char *address,*label;
    const char *start=wguide+wh[h].start,*stop=wguide+end;
    wh[h].end=end;
    if(field(start,stop,"file_name",wh[h].file,W_PATH)||
        field(start,stop,"function_name",wh[h].label,W_NAME)||
        field(start,stop,"declaration",decl,sizeof decl))return 1;
    label=strstr(wh[h].heading," — ");
    if(!label||strcmp(label+strlen(" — "),wh[h].label))return w_fail("prior_heading_name_mismatch",wh[h].label);
    if(snprintf(expected,sizeof expected,"%c%c-%02d",wh[h].section,wh[h].subsection,wh[h].number)<0)return 1;
    address=strstr(start,"<function_address>");
    if(address&&address<stop){
        if(field(start,stop,"function_address",actual,sizeof actual)||strcmp(actual,expected))return w_fail("prior_xml_address_mismatch",wh[h].label);
    }
    if(w_copy(wh[h].decl,W_DECL,decl))return 1;
    p=strchr(decl,'(');if(!p)return w_fail("prior_declaration",wh[h].label);
    while(p>decl&&isspace((unsigned char)p[-1]))--p;
    q=p;while(q>decl&&(isalnum((unsigned char)q[-1])||q[-1]=='_'))--q;
    if(q==p)return w_fail("prior_source_name",wh[h].label);
    wh[h].current=-1;return bounded(q,p,wh[h].name,W_NAME);
}
int w_load_homes(void)
{
    const char *start,*end,*p;int sec=-1,sub=-1,active=-1,in_fence=0;
    if(w_read(wprevious,wguide,W_GUIDE,&wguide_len))return 1;
    start=strstr(wguide,"<!-- GENERATED:CURRENT_BUILD:BEGIN -->\n");
    end=strstr(wguide,"<!-- GENERATED:CURRENT_BUILD:END -->");
    if(!start||!end||end<=start)return w_fail("prior_current_build_region",wprevious);
    for(p=start;p<end;){const char *e=memchr(p,'\n',(size_t)(end-p));size_t len;
        if(!e)e=end;
        len=(size_t)(e-p);
        if(len>=3&&!memcmp(p,"```",3))in_fence=!in_fence;
        if(!in_fence&&len>=4&&p[0]=='#'){
            int issec=len>=12&&!memcmp(p,"### SECTION ",12);
            int issub=len>=16&&!memcmp(p,"#### SubSection ",16);
            int isfn=len>=14&&!memcmp(p,"##### function",14);
            if(issec||issub||isfn){
                if(active>=0&&finish_home(active,(size_t)(p-wguide)))return 1;
                active=-1;
            }
            if(issec){
                sec=(int)p[12]-'A';sub=-1;
                if(sec<0||sec>=15||wsections[sec][0])return w_fail("prior_section_identity","");
                if(bounded(p,e,wsections[sec],W_PATH))return 1;
            }
            if(issub){
                sub=(int)p[16]-'a';
                if(sec<0||sub<0||sub>=26||wsubsections[sec][sub][0])return w_fail("prior_subsection_identity","");
                if(bounded(p,e,wsubsections[sec][sub],W_PATH))return 1;
            }
            if(isfn){char number[12];const char *q=p+14,*r;int n;
                while(q<e&&*q==' ')++q;
                r=q;while(r<e&&isdigit((unsigned char)*r))++r;
                if(bounded(q,r,number,sizeof number))return 1;
                n=atoi(number);
                if(sec<0||sub<0||n<1||n>99||wnhome==W_FUNCS)return w_fail("prior_function_address",number);
                active=wnhome++;wh[active].section=(char)('A'+sec);wh[active].subsection=(char)('a'+sub);
                wh[active].number=n;wh[active].start=(size_t)(p-wguide);
                if(bounded(p,e,wh[active].heading,W_PATH))return 1;
            }
        }
        p=e<end?e+1:e;
    }
    if(active>=0&&finish_home(active,(size_t)(end-wguide)))return 1;
    if(in_fence||!wnhome)return w_fail("prior_inventory_empty_or_fence",wprevious);
    {int i,present=0;for(i=0;i<15;++i){int required=(i<10||i==12||i==13);
        if(required&&!wsections[i][0])return w_fail("locked_section_missing","");
        if(wsections[i][0])++present;
    }if(present!=12&&present!=15)return w_fail("partial_section_registry","");}
    return 0;
}
int w_bind_homes(void)
{
    int i,j;
    for(i=0;i<wnhome;++i){
        for(j=0;j<i;++j){
            if(wh[i].section==wh[j].section&&wh[i].subsection==wh[j].subsection&&wh[i].number==wh[j].number)
                return w_fail("duplicate_prior_address",wh[i].heading);
            if(!strcmp(wh[i].file,wh[j].file)&&!strcmp(wh[i].name,wh[j].name))
                return w_fail("duplicate_prior_source_identity",wh[i].name);
        }
        for(j=0;j<wnfile;++j)if(!strcmp(wf[j].path,wh[i].file)){
            int f=w_find(j,wh[i].name);
            if(wf[j].section&&(wf[j].section!=wh[i].section||wf[j].subsection!=wh[i].subsection))
                return w_fail("file_has_multiple_homes",wf[j].path);
            wf[j].section=wh[i].section;wf[j].subsection=wh[i].subsection;
            if(f>=0){
                const char *a=wh[i].decl,*b=wn[f].decl;
                for(;;){while(isspace((unsigned char)*a))++a;while(isspace((unsigned char)*b))++b;
                    if(*a!=*b){wh[i].declaration_changed=1;break;}
                    if(!*a)break;
                    ++a;++b;
                }
                wh[i].current=f;wn[f].home=i;
            }
        }
    }
    /* New source functions inherit only the file's proven home. New files
     * have no heuristic placement and remain OPEN in the separate findings. */
    for(i=0;i<wnfunc;++i)if(wn[i].home<0&&wf[wn[i].file].section){
        int n=0;w_file *f=&wf[wn[i].file];w_home *h;char heading[W_PATH];
        for(j=0;j<wnhome;++j)if(wh[j].section==f->section&&wh[j].subsection==f->subsection&&wh[j].number>n)n=wh[j].number;
        if(n>=99||wnhome==W_FUNCS)return w_fail("issued_address_capacity",wn[i].name);
        h=&wh[wnhome];h->section=f->section;h->subsection=f->subsection;h->number=n+1;h->current=i;
        if(w_copy(h->file,W_PATH,f->path)||w_copy(h->name,W_NAME,wn[i].name)||w_copy(h->label,W_NAME,wn[i].name))return 1;
        if(snprintf(heading,sizeof heading,"##### function %02d — %s",h->number,h->label)<0||w_copy(h->heading,W_PATH,heading))return 1;
        wn[i].home=wnhome++;
    }
    return 0;
}

/* Module: walk_inventory.c */
#include <string.h>
#include <inttypes.h>

void w_identity(FILE *out,int f)
{w_field(out,wf[wn[f].file].path);fputc('#',out);w_field(out,wn[f].name);}
void w_address(FILE *out,int f)
{int h=wn[f].home;if(h<0)fputs("OPEN",out);else fprintf(out,"%c%c-%02d",wh[h].section,wh[h].subsection,wh[h].number);}
void w_span(FILE *out,int file,size_t start,size_t end,int xml)
{
    const char *s=wsource+wf[file].offset;size_t i;char unit[2];unit[1]=0;
    for(i=start;i<end;++i){unit[0]=s[i];if(xml)w_xml(out,unit);else w_field(out,unit);}
}
static void dep(FILE *out,int i)
{if(wc[i].to>=0)w_identity(out,wc[i].to);else{fputc('?',out);w_field(out,wc[i].target);}}
int w_emit_registry(FILE *out)
{
    int i,j,k,f,flow;
    fprintf(out,"FORMAT|shakti_source_walk|1\nSOURCE|%s\nPRIOR|%016" PRIX64 "|%lu\n",wrevision,w_pin(wguide,wguide_len),(unsigned long)wguide_len);
    w_reader_records(out);
    w_document_records(out);
    fputs("ROOT|",out);w_identity(out,wroot_function);fputc('\n',out);
    for(i=0;i<wnfile;++i){
        fputs("FILE|",out);w_field(out,wf[i].path);fprintf(out,"|%lu|%016" PRIX64 "|%d\n",(unsigned long)wf[i].length,wf[i].pin,wf[i].count);
        fputs("BYTES|",out);w_field(out,wf[i].path);fputc('|',out);w_span(out,i,0,wf[i].length,0);fputc('\n',out);
        fputs("BLOB|",out);w_field(out,wf[i].path);fprintf(out,"|%s|%s|%s\n",wf[i].git_sha[0]?wf[i].git_sha:"unprovided",wf[i].actual_git_sha,
            !wf[i].git_sha[0]?"unverified_base":!strcmp(wf[i].git_sha,wf[i].actual_git_sha)?"matches_tree":"modified_from_tree");
        if(wf[i].unparsed_tail){fputs("SOURCE_GAP|",out);w_field(out,wf[i].path);fprintf(out,"|%lu|%lu|unparsed_tail\n",(unsigned long)wf[i].unparsed_tail,(unsigned long)wf[i].length);}
        if(wf[i].syntax_gaps){fputs("SOURCE_GAP|",out);w_field(out,wf[i].path);fprintf(out,"|0|%lu|unmatched_top_level_closes=%d\n",(unsigned long)wf[i].length,wf[i].syntax_gaps);}
    }
    for(flow=0;flow<wnfunc;++flow){
        for(f=0;f<wnfunc&&wn[f].flow!=flow;++f){}
        if(f==wnfunc)return w_fail("flow_not_permutation","");
        fputs("FN|",out);w_field(out,wf[wn[f].file].path);fputc('|',out);w_field(out,wn[f].name);
        fputc('|',out);w_field(out,wn[f].type);fputc('|',out);w_field(out,wn[f].decl);
        fprintf(out,"|%lu|%lu|",(unsigned long)wn[f].start,(unsigned long)wn[f].end);
        k=0;
        for(i=0;i<wncall;++i)if(wc[i].from==f){int duplicate=0;
            for(j=0;j<i;++j)if(wc[j].from==f&&wc[j].to==wc[i].to&&!strcmp(wc[j].target,wc[i].target)){duplicate=1;break;}
            if(!duplicate){if(k++)fputc(',',out);dep(out,i);}
        }fputc('\n',out);
        fputs("AT|",out);w_identity(out,f);fprintf(out,"|%d|%d|%016" PRIX64 "|",wn[f].flow,wn[f].depth,wn[f].pin);w_address(out,f);fputc('\n',out);
        for(i=0;i<wn[f].inputs;++i){w_input *a=&wn[f].input[i];
            fputs("IN|",out);w_identity(out,f);fprintf(out,"|%d|",i+1);w_field(out,a->name);fputc('|',out);w_field(out,a->type);
            fputc('|',out);w_field(out,a->decl);fprintf(out,"|%lu|%lu\n",(unsigned long)a->start,(unsigned long)a->end);
        }
        fputs("OUT|",out);w_identity(out,f);fputs("|return|",out);w_field(out,wn[f].type);
        fprintf(out,"|%s\n",!strcmp(wn[f].type,"void")?"no_value":"declared_return");
        for(i=0;i<wneffect;++i)if(we[i].owner==f){
            fputs("EFFECT|",out);w_identity(out,f);fprintf(out,"|%lu|%lu|%s|",(unsigned long)we[i].site,(unsigned long)we[i].end,we[i].kind);
            w_field(out,we[i].identity);fputc('|',out);w_field(out,we[i].type);fputc('\n',out);
        }
        for(i=0;i<wncall;++i)if(wc[i].from==f){
            fputs("CALL|",out);w_identity(out,f);fprintf(out,"|%lu|%lu|",(unsigned long)wc[i].site,(unsigned long)wc[i].end);
            dep(out,i);fprintf(out,"|%d|%s\n",wc[i].argc,wc[i].to>=0?"direct_definition":"unresolved_external_macro_or_indirect");
            for(j=0;j<wc[i].argc;++j){fputs("ARG|",out);w_identity(out,f);fprintf(out,"|%lu|%d|",(unsigned long)wc[i].site,j+1);
                w_span(out,wn[f].file,wc[i].arg_start[j],wc[i].arg_end[j],0);fputc('|',out);
                if(wc[i].to>=0&&j<wn[wc[i].to].inputs)w_field(out,wn[wc[i].to].input[j].type);else fputs("unresolved",out);
                fputc('\n',out);
                if(wc[i].to>=0&&j<wn[wc[i].to].inputs){int inner;
                    for(inner=0;inner<wncall;++inner)if(wc[inner].from==f&&wc[inner].to>=0&&wc[inner].site==wc[i].arg_start[j]&&wc[inner].end==wc[i].arg_end[j]&&
                        !strcmp(wn[wc[inner].to].type,wn[wc[i].to].input[j].type)){
                        fputs("BIND|",out);w_identity(out,wc[inner].to);fputs("|return|",out);w_identity(out,wc[i].to);fprintf(out,"|%d|",j+1);w_identity(out,f);
                        fprintf(out,"|%lu|%lu|exact_nested_call_and_declared_type\n",(unsigned long)wc[i].site,(unsigned long)wc[inner].site);
                    }
                }
            }
        }
    }
    for(i=0;i<wnhome;++i)if(wh[i].current<0){fprintf(out,"RESERVED|%c%c-%02d|",wh[i].section,wh[i].subsection,wh[i].number);w_field(out,wh[i].file);fputc('|',out);w_field(out,wh[i].name);fputc('\n',out);}
    for(i=0;i<wnhome;++i)if(wh[i].declaration_changed){fprintf(out,"DECL_CHANGE|%c%c-%02d|",wh[i].section,wh[i].subsection,wh[i].number);w_field(out,wh[i].decl);fputc('|',out);w_field(out,wn[wh[i].current].decl);fputc('\n',out);}
    return ferror(out)?w_fail("registry_write",""):0;
}
void w_function_xml(FILE *out,int f)
{
    int i,j;w_function *n=&wn[f];
    fputs("<function>\n<name>",out);w_xml(out,n->name);fputs("</name>\n<address>",out);w_address(out,f);
    fprintf(out,"</address>\n<depth>%d</depth>\n<flow_order>%d</flow_order>\n<inputs>\n",n->depth,n->flow);
    for(i=0;i<n->inputs;++i){fprintf(out,"<input ordinal=\"%d\"><name>",i+1);w_xml(out,n->input[i].name);
        fputs("</name><type>",out);w_xml(out,n->input[i].type);fputs("</type></input>\n",out);}
    fputs("</inputs>\n<outputs>\n<output id=\"return\"><type>",out);w_xml(out,n->type);
    fprintf(out,"</type><kind>%s</kind></output>\n",!strcmp(n->type,"void")?"no_value":"declared_return");
    fputs("</outputs>\n<effects>\n",out);
    for(i=0;i<wneffect;++i)if(we[i].owner==f){
        fprintf(out,"<effect id=\"%s_%lu\"><type>",we[i].kind,(unsigned long)we[i].site);w_xml(out,we[i].type);
        fputs("</type><expression>",out);w_xml(out,we[i].identity);fprintf(out,"</expression><start>%lu</start><end>%lu</end></effect>\n",(unsigned long)we[i].site,(unsigned long)we[i].end);
    }
    fputs("</effects>\n<callees>\n",out);
    for(i=0;i<wncall;++i)if(wc[i].from==f){
        fprintf(out,"<call site=\"%lu\" state=\"%s\"><name>",(unsigned long)wc[i].site,wc[i].to>=0?"direct_definition":"open");
        w_xml(out,wc[i].target);fputs("</name>",out);
        if(wc[i].to>=0){fputs("<filename>",out);w_xml(out,wf[wn[wc[i].to].file].path);fputs("</filename>",out);}
        for(j=0;j<wc[i].argc;++j){fprintf(out,"<argument ordinal=\"%d\">",j+1);w_span(out,n->file,wc[i].arg_start[j],wc[i].arg_end[j],1);fputs("</argument>",out);}
        fputs("</call>\n",out);
    }
    fputs("</callees>\n<callers>\n",out);
    for(i=0;i<wncall;++i)if(wc[i].to==f){fprintf(out,"<caller site=\"%lu\"><filename>",(unsigned long)wc[i].site);w_xml(out,wf[wn[wc[i].from].file].path);
        fputs("</filename><name>",out);w_xml(out,wn[wc[i].from].name);fputs("</name></caller>\n",out);}
    fprintf(out,"</callers>\n<source_pin algorithm=\"fnv1a64\">%016" PRIX64 "</source_pin>\n</function>\n",n->pin);
}
int w_emit_xml(FILE *out,int section)
{
    int i,j;fputs("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<function_inventory>\n",out);
    for(i=0;i<wnfile;++i)if(section<0||wf[i].section==section){
        fputs("<filename id=\"",out);w_xml(out,wf[i].path);fputs("\">\n",out);
        for(j=0;j<wnfunc;++j)if(wn[j].file==i)w_function_xml(out,j);
        fputs("</filename>\n",out);
    }fputs("</function_inventory>\n",out);return ferror(out)?w_fail("xml_write",""):0;
}
int w_emit_flags(FILE *out)
{
    int i;fputs("FORMAT|shakti_findings|1\n",out);
    for(i=0;i<wnfile;++i){
        if(wf[i].git_sha[0]&&strcmp(wf[i].git_sha,wf[i].actual_git_sha))fprintf(out,"OPEN|modified_from_tree|%s|%s|%s\n",wf[i].path,wf[i].git_sha,wf[i].actual_git_sha);
        if(wf[i].unparsed_tail)fprintf(out,"OPEN|source_tail|%s|%lu|%lu\n",wf[i].path,(unsigned long)wf[i].unparsed_tail,(unsigned long)wf[i].length);
        if(wf[i].syntax_gaps)fprintf(out,"OPEN|top_level_delimiter|%s|%d\n",wf[i].path,wf[i].syntax_gaps);
    }
    for(i=0;i<wnfunc;++i){
        if(wn[i].depth<0){fputs("OPEN|not_reached_by_resolved_direct_calls|",out);w_identity(out,i);fputc('\n',out);}
        if(wn[i].home<0){fputs("OPEN|no_issued_home|",out);w_identity(out,i);fputc('\n',out);}
    }
    for(i=0;i<wncall;++i)if(wc[i].to<0){fputs("OPEN|call_target|",out);w_identity(out,wc[i].from);fprintf(out,"|%lu|",(unsigned long)wc[i].site);w_field(out,wc[i].target);fputc('\n',out);}
    for(i=0;i<wnhome;++i)if(wh[i].current<0)fprintf(out,"OPEN|prior_only_reserved|%c%c-%02d|%s|%s\n",wh[i].section,wh[i].subsection,wh[i].number,wh[i].file,wh[i].name);
    for(i=0;i<wnhome;++i)if(wh[i].declaration_changed){fprintf(out,"OPEN|declaration_change|%c%c-%02d|",wh[i].section,wh[i].subsection,wh[i].number);w_field(out,wh[i].decl);fputc('|',out);w_field(out,wn[wh[i].current].decl);fputc('\n',out);}
    fputs("LIMIT|preprocessor|all visible branches; macro expansions and conditional build reachability are not inferred\nLIMIT|effects|return expressions and lexical write/call sites; alias and transitive runtime effects remain unresolved\n",out);
    return ferror(out)?w_fail("findings_write",""):0;
}
int w_check_registry(const char *path)
{
    FILE *expected=tmpfile(),*actual=fopen(path,"rb");int equal;
    if(!expected||!actual){if(expected)fclose(expected);if(actual)fclose(actual);return w_fail("cannot_check_registry",path);}
    if(w_emit_registry(expected)||fflush(expected)){fclose(actual);fclose(expected);return 1;}
    rewind(expected);equal=w_equal(expected,actual);
    if(fclose(actual)||fclose(expected))return w_fail("registry_check_close",path);
    return equal?0:w_fail("registry_source_or_template_mismatch",path);
}
int w_output_open(const char *path,FILE **out)
{
    char pending[W_PATH*2];FILE *probe=fopen(path,"rb");int n;
    if(probe){fclose(probe);return w_fail("output_exists",path);}
    n=snprintf(pending,sizeof pending,"%s.pending",path);
    if(n<0||(size_t)n>=sizeof pending)return w_fail("output_path_capacity",path);
    probe=fopen(pending,"rb");if(probe){fclose(probe);return w_fail("pending_output_exists",pending);}
    *out=fopen(pending,"wb");return *out?0:w_fail("cannot_create_output",pending);
}
int w_output_close(FILE *out,const char *path)
{int bad=ferror(out);if(fclose(out))bad=1;return bad?w_fail("output_write",path):0;}
int w_commit_output(const char *path)
{char pending[W_PATH*2];if(snprintf(pending,sizeof pending,"%s.pending",path)<0)return 1;return rename(pending,path)?w_fail("output_publish",path):0;}
int w_inventory(const char *config,const char *registry,const char *xml,const char *flags)
{
    FILE *r,*x,*f;int a,b,c;
    if(w_prepare(config))return 1;
    if(w_output_open(registry,&r))return 1;
    a=w_emit_registry(r);b=w_output_close(r,registry);if(a||b)return 1;
    if(w_output_open(xml,&x))return 1;
    a=w_emit_xml(x,-1);b=w_output_close(x,xml);if(a||b)return 1;
    if(w_output_open(flags,&f))return 1;
    a=w_emit_flags(f);b=w_output_close(f,flags);if(a||b)return 1;
    a=w_commit_output(registry);b=w_commit_output(xml);c=w_commit_output(flags);if(a||b||c)return 1;
    printf("INVENTORY|files=%d|functions=%d|calls=%d|effects=%d|unresolved_calls=%d\n",wnfile,wnfunc,wncall,wneffect,wunknown);return 0;
}

/* Module: walk_decide.c */
#include <string.h>
#include <ctype.h>

typedef struct {int fn,arg,count;} question;
typedef struct {int fn,priority,bonus;} candidate;
static question questions[W_FUNCS*W_ARGS];
static candidate options[W_FUNCS];
static int same_dir(int a,int b)
{
    const char *x=strrchr(wf[a].path,'/'),*y=strrchr(wf[b].path,'/');
    size_t nx=x?(size_t)(x-wf[a].path):0,ny=y?(size_t)(y-wf[b].path):0;
    return nx==ny&&!memcmp(wf[a].path,wf[b].path,nx);
}
static int same_word(const char *a,const char *b)
{
    const char *p=a;
    while(*p){const char *q=p,*r=b;while(*q&&*q!='_')++q;
        if(q-p>1)while(*r){const char *s=r;size_t n=(size_t)(q-p),i;
            while(*s&&*s!='_')++s;
            if((size_t)(s-r)==n){for(i=0;i<n&&tolower((unsigned char)p[i])==tolower((unsigned char)r[i]);++i){}
                if(i==n)return 1;}
            r=*s?s+1:s;
        }p=*q?q+1:q;
    }return 0;
}
static int includes_file(int receiver,int producer)
{
    const char *s=wsource+wf[receiver].offset,*last=s+wf[receiver].length;
    const char *base=strrchr(wf[producer].path,'/');base=base?base+1:wf[producer].path;
    while(s<last){const char *e=strchr(s,'\n'),*p=s;
        if(!e)e=last;
        while(p<e&&(*p==' '||*p=='\t'))++p;
        if(p<e&&*p++=='#'){
            while(p<e&&(*p==' '||*p=='\t'))++p;
            if(e-p>=7&&!memcmp(p,"include",7)){const char *a,*b;p+=7;
                while(p<e&&(*p==' '||*p=='\t'))++p;
                if(p<e&&*p=='"'){a=++p;b=memchr(a,'"',(size_t)(e-a));
                    if(b){size_t n=(size_t)(b-a);
                        if((n==strlen(wf[producer].path)&&!memcmp(a,wf[producer].path,n))||
                            (same_dir(receiver,producer)&&n==strlen(base)&&!memcmp(a,base,n)))return 1;
                    }
                }
            }
        }s=e<last?e+1:e;
    }return 0;
}
static int priority(int a,int b)
{
    int x=wn[a].home,y=wn[b].home;
    if(wn[a].file==wn[b].file)return 1;
    if(x>=0&&y>=0&&wh[x].section==wh[y].section&&wh[x].subsection==wh[y].subsection)return 1;
    if((x>=0&&y>=0&&wh[x].section==wh[y].section)||same_dir(wn[a].file,wn[b].file))return 2;
    return 3;
}
static int name_order(int a,int b)
{
    int d=strcmp(wf[wn[a].file].path,wf[wn[b].file].path);
    return d?d:strcmp(wn[a].name,wn[b].name);
}
static int before_question(question a,question b)
{
    int d;if(a.count!=b.count)return a.count<b.count;
    d=name_order(a.fn,b.fn);return d?d<0:a.arg<b.arg;
}
static int before_option(candidate a,candidate b)
{
    if(a.priority!=b.priority)return a.priority<b.priority;
    if(a.bonus!=b.bonus)return a.bonus>b.bonus;
    return name_order(a.fn,b.fn)<0;
}
static int in_scope(int file,const char *scope)
{
    return !strcmp(scope,"ALL")||(wf[file].section==scope[0]&&(!scope[1]||wf[file].subsection==scope[1]));
}
int w_decide(const char *config,const char *registry,const char *output,const char *scope)
{
    int i,j,k,nq=0;FILE *out;
    if(w_prepare(config)||w_check_registry(registry))return 1;
    if(strcmp(scope,"ALL")&&(strlen(scope)>2||scope[0]<'A'||scope[0]>'O'||!wsections[scope[0]-'A'][0]||
        (scope[1]&&(scope[1]<'a'||scope[1]>'z'||!wsubsections[scope[0]-'A'][scope[1]-'a'][0]))))return w_fail("scope_not_in_prior",scope);
    for(i=0;i<wnfunc;++i)for(j=0;j<wn[i].inputs;++j){question q;int n=0;
        if(!in_scope(wn[i].file,scope))continue;
        if(!strcmp(wn[i].input[j].name,"variadic"))continue;
        for(k=0;k<wnfunc;++k)if(k!=i&&!strcmp(wn[i].input[j].type,wn[k].type)&&strcmp(wn[k].type,"void"))++n;
        q.fn=i;q.arg=j;q.count=n;questions[nq++]=q;
    }
    for(i=1;i<nq;++i){question q=questions[i];j=i;
        while(j>0&&before_question(q,questions[j-1])){questions[j]=questions[j-1];--j;}questions[j]=q;
    }
    if(w_output_open(output,&out))return 1;
    fputs("FORMAT|shakti_connector_questions|1\nDECISION_WORDS|KEEP|REMOVE|RELOCATE\nPOLICY|exact_declared_return_type|1=same_file_or_subsection|2=same_section_or_folder|3=elsewhere|bonus=shared_name_word+direct_include|fewest_options_first\n",out);
    fprintf(out,"SCOPE|%s\n",scope);
    for(i=0;i<wnfile;++i)if(in_scope(i,scope)){fputs("KEEP|",out);w_field(out,wf[i].path);fputs("|inventoried_source; no source edit performed\n",out);}
    for(i=0;i<nq;++i){question q=questions[i];int n=0;
        fputs("QUESTION|",out);w_identity(out,q.fn);fprintf(out,"|%d|",q.arg+1);w_field(out,wn[q.fn].input[q.arg].type);fprintf(out,"|%d|",q.count);w_address(out,q.fn);fputc('\n',out);
        for(j=0;j<wnfunc;++j)if(j!=q.fn&&!strcmp(wn[q.fn].input[q.arg].type,wn[j].type)&&strcmp(wn[j].type,"void")){
            candidate c;c.fn=j;c.priority=priority(q.fn,j);c.bonus=same_word(wn[q.fn].name,wn[j].name)+includes_file(wn[q.fn].file,wn[j].file);options[n++]=c;
        }
        for(j=1;j<n;++j){candidate c=options[j];k=j;while(k>0&&before_option(c,options[k-1])){options[k]=options[k-1];--k;}options[k]=c;}
        for(j=0;j<n;++j){fputs("CANDIDATE|",out);w_identity(out,q.fn);fprintf(out,"|%d|%d|",q.arg+1,j+1);w_identity(out,options[j].fn);
            fprintf(out,"|return|%d|%d|PROPOSED\n",options[j].priority,options[j].bonus);}
    }
    fputs("LIMIT|candidate_score_is_not_a_connection|No candidates close endpoints or remove/relocate source. KEEP preserves the source inventory; REMOVE/RELOCATE require an explicit source work order and a subsequent source inventory.\n",out);
    if(w_output_close(out,output)||w_commit_output(output))return 1;
    printf("DECIDE|questions=%d|automatic_bindings=0\n",nq);return 0;
}

/* Module: walk_generate.c */
#include <string.h>
#include <inttypes.h>

static const char *regions[]={"HEADING_INDEX","FLOWCHART","FILE_REGISTRY","DEFINITIONS","CURRENT_BUILD","FUNCTION_REGISTRY","PROJECT_FILES","AMENDMENTS"};
static const char *begin[8],*end[8];
static int boundaries(void)
{
    int i;
    for(i=0;i<8;++i){char a[96],b[96];
        if(snprintf(a,sizeof a,"<!-- GENERATED:%s:BEGIN -->\n",regions[i])<0||snprintf(b,sizeof b,"<!-- GENERATED:%s:END -->",regions[i])<0)return 1;
        begin[i]=strstr(wguide,a);end[i]=strstr(wguide,b);
        if(!begin[i]||!end[i]||end[i]<begin[i]||(i&&begin[i]<end[i-1]))return w_fail("generated_region_order",regions[i]);
        begin[i]+=strlen(a);
        if(strstr(end[i]+strlen(b),a)||strstr(end[i]+strlen(b),b))return w_fail("duplicate_generated_region",regions[i]);
    }return 0;
}
static void index_view(FILE *out)
{
    int s,t,h;
    w_reader_glossary(out);w_reader_key(out);w_reader_tree(out);
    fputs("<a id=\"heading_index\"></a>\n\n<details>\n<summary>Complete heading index — all issued function homes</summary>\n\n",out);
    fputs("The enforced order is `# TITLE / # CHAPTER / ### SECTION / #### SubSection / ##### function`. Chapters I through XI are level-one headings. Established section, subsection, and function heading levels remain fixed.\n\n",out);
    for(s=0;s<11;++s){const char *p=wchapters[s],*e=strchr(p,'\n');while(*p=='#')++p;if(*p==' ')++p;fputs("- ",out);fwrite(p,1,(size_t)(e-p),out);fputc('\n',out);}
    fputc('\n',out);
    for(s=0;s<15;++s)if(wsections[s][0]){
        fprintf(out,"- %s\n",wsections[s]+4);
        for(t=0;t<26;++t)if(wsubsections[s][t][0]){
            fprintf(out,"  - %s\n",wsubsections[s][t]+5);
            for(h=0;h<wnhome;++h)if(wh[h].section=='A'+s&&wh[h].subsection=='a'+t){
                fputs("    - ",out);w_reader_link(out,h);
                fprintf(out," %s%s\n",wh[h].label,wh[h].current<0?" [PRIOR_ONLY / RESERVED]":"");
            }
        }
    }
    fputs("\n</details>\n\n",out);
}
static void graph_view(FILE *out)
{
    int i;fputs("<details>\n<summary>Complete source graph — every recorded call site</summary>\n\n",out);
    fputs("For the smaller names-only view, use the [simple function tree](#function_tree).\n\n```mermaid\nflowchart TB\n",out);
    for(i=0;i<wnfunc;++i){fprintf(out,"    f%d[\"",i);w_address(out,i);fputs(" : ",out);fputs(wn[i].name,out);fputs("\"]\n",out);}
    for(i=0;i<wncall;++i){
        if(wc[i].to>=0)fprintf(out,"    f%d -->|\"%lu\"| f%d\n",wc[i].from,(unsigned long)wc[i].site,wc[i].to);
        else{fprintf(out,"    x%d[\"OPEN : %s\"]\n",i,wc[i].target);fprintf(out,"    f%d -.->|\"%lu\"| x%d\n",wc[i].from,(unsigned long)wc[i].site,i);}
    }fputs("```\n\nEdge labels are original-file byte offsets. Solid edges resolve one source definition; dotted edges retain unresolved external, macro, or indirect targets. The graph inventories visible source branches; it does not certify build-specific reachability.\n\n</details>\n\n",out);
}
static void old_logical(FILE *out,const char *file)
{
    const char *p=begin[2];size_t n=strlen(file);
    while(p<end[2]){const char *q=strchr(p,'\n');
        if(!q||q>end[2])break;
        if((size_t)(q-p)>n+4&&!memcmp(p,"| ",2)&&!memcmp(p+2,file,n)&&p[n+2]==' '&&p[n+3]=='|'){
            const char *a=p;int k=0;
            while(a<q){if(*a=='|'&&++k==5){const char *b=strchr(a+1,'|');if(b&&b<q){fwrite(a+1,1,(size_t)(b-a-1),out);return;}}++a;}
        }p=q+1;
    }fputs(" OPEN ",out);
}
static void files_view(FILE *out)
{
    int i;fputs("| Filename | Current Section | Current SubSection | Functions | Logical See Homes |\n|---|---:|---:|---:|---|\n",out);
    for(i=0;i<wnfile;++i){fprintf(out,"| %s | ",wf[i].path);
        if(wf[i].section)fprintf(out,"%c | %c",wf[i].section,wf[i].subsection);else fputs("OPEN | OPEN",out);
        fprintf(out," | %d |",wf[i].count);old_logical(out,wf[i].path);fputs("|\n",out);
    }fputc('\n',out);
}
static void definition_view(FILE *out)
{
    int i;fputs("| Filename | Function | Declaration | Source Pin (FNV-1a 64) |\n|---|---|---|---|\n",out);
    for(i=0;i<wnfunc;++i){fprintf(out,"| %s | %s | `",wf[wn[i].file].path,wn[i].name);w_field(out,wn[i].decl);fprintf(out,"` | %016" PRIX64 " |\n",wn[i].pin);}fputc('\n',out);
}
static void function_block(FILE *out,int h,int code)
{
    w_home *home=&wh[h];int f=home->current;
    if(f<0){
        fprintf(out,"%s\n\nRecord Status: PRIOR_ONLY — address reserved; absent from this source snapshot.\n\n",home->heading);
        if(home->end>home->start){const char *p=strchr(wguide+home->start,'\n');
            if(p&&p<wguide+home->end){
                const char *status=strstr(p,"Record Status: PRIOR_ONLY");
                if(status&&status<p+4){const char *next=strstr(status,"\n\n");if(next)p=next+1;}
                fwrite(p+1,1,home->end-(size_t)(p+1-wguide),out);
            }
        }return;
    }
    fprintf(out,"%s\n\n",home->heading);
    if(code)fprintf(out,"<a id=\"function_%c%c_%02d\"></a>\n\n",home->section,home->subsection,home->number);
    fprintf(out,"Function Address: %c%c-%02d\n\nFunction Name: %s\n\n",home->section,home->subsection,home->number,home->label);
    fputs("```xml\n<function_record>\n<file_name>",out);w_xml(out,wf[wn[f].file].path);
    fputs("</file_name>\n<function_name>",out);w_xml(out,home->label);
    fputs("</function_name>\n<return_type>",out);w_xml(out,wn[f].type);
    fputs("</return_type>\n<declaration>",out);w_xml(out,wn[f].decl);fputs("</declaration>\n",out);
    w_function_xml(out,f);fputs("</function_record>\n```\n\n",out);
    if(code){fputs("Code:\n\n```c\n",out);fwrite(wsource+wf[wn[f].file].offset+wn[f].start,1,wn[f].end-wn[f].start,out);fputs("\n```\n\n",out);}
    fputs("----\n\n",out);
}
static void build_view(FILE *out,int code)
{
    int s,t,h,n;
    for(s=0;s<15;++s)if(wsections[s][0]){
        fprintf(out,"%s\n\n",wsections[s]);
        if(code)fprintf(out,"<a id=\"section_%c\"></a>\n\n",'A'+s);
        w_reader_section(out,s);
        for(t=0;t<26;++t)if(wsubsections[s][t][0]){
            fprintf(out,"%s\n\n",wsubsections[s][t]);
            /* Both views retain issued addresses. VII orders labels without
             * renumbering; VI retains the issued-number order. */
            if(code){
                for(n=1;n<=99;++n)for(h=0;h<wnhome;++h)
                    if(wh[h].section=='A'+s&&wh[h].subsection=='a'+t&&wh[h].number==n)function_block(out,h,code);
            }else{
                int ordered[99],count=0,j;
                for(h=0;h<wnhome;++h)if(wh[h].section=='A'+s&&wh[h].subsection=='a'+t){
                    if(count==99){w_fail("subsection_function_capacity","");return;}
                    ordered[count++]=h;
                }
                for(h=1;h<count;++h){int item=ordered[h];j=h;
                    while(j>0&&strcmp(wh[item].label,wh[ordered[j-1]].label)<0){ordered[j]=ordered[j-1];--j;}ordered[j]=item;
                }
                for(h=0;h<count;++h)function_block(out,ordered[h],code);
            }
        }
    }
    for(h=0;h<wnfunc;++h)if(wn[h].home<0){
        fputs("Unplaced source identity: `",out);w_identity(out,h);fputs("` (OPEN; no section assigned).\n\n```xml\n",out);w_function_xml(out,h);fputs("```\n\n",out);
    }
}
static void source_view(FILE *out)
{
    int i;
    for(i=0;i<wnfile;++i){fprintf(out,"File: `%s`\n\nSource Bytes: %lu\n\nSource Pin (FNV-1a 64): %016" PRIX64 "\n\n```text\n",wf[i].path,(unsigned long)wf[i].length,wf[i].pin);
        fwrite(wsource+wf[i].offset,1,wf[i].length,out);fputs("\n```\n\n",out);
    }
}
static void amendment_view(FILE *out)
{
    int i;const char *old_end=end[7];uint64_t prior=w_pin(wguide,wguide_len);
    fwrite(begin[7],1,(size_t)(old_end-begin[7]),out);
    fprintf(out,"\n<!-- NATIVE_AMENDMENT -->\nSOURCE_REVISION: %s\n\nPRIOR_GUIDE_PIN_FNV1A64: %016" PRIX64 "\n\n",wrevision,prior);
    fputs("| Address | Filename | Source Function | Current State | Current Source Pin |\n|---|---|---|---|---|\n",out);
    for(i=0;i<wnhome;++i){int f=wh[i].current;
        fprintf(out,"| %c%c-%02d | %s | %s | %s | ",wh[i].section,wh[i].subsection,wh[i].number,wh[i].file,wh[i].name,f<0?"PRIOR_ONLY / RESERVED":"SOURCE_VERIFIED");
        if(f>=0)fprintf(out,"%016" PRIX64,wn[f].pin);else fputs("not in current source",out);fputs(" |\n",out);
    }
    fputs("\nGenerated function facts replace prior derived facts in their original regions. The accepted prior guide remains the byte-exact historical input identified above. Document format 1 promotes the eleven chapter headings to H1 and updates the exact reading-order sentence. It inserts the fixed supervisor entry once and, when supplied, preserves the complete supervision reference in Chapter IX. All other bytes outside generated regions are carried verbatim. Unresolved source, call, and effect findings are emitted separately.\n\n",out);
}
int w_render_guide(FILE *out)
{
    int i;const char *cursor=wguide;
    if(boundaries())return 1;
    for(i=0;i<8;++i){w_document_copy(out,cursor,begin[i]);
        switch(i){case 0:index_view(out);break;case 1:graph_view(out);break;case 2:files_view(out);break;case 3:definition_view(out);break;
        case 4:build_view(out,1);break;case 5:build_view(out,0);break;case 6:source_view(out);break;case 7:amendment_view(out);break;default:return 1;}
        cursor=end[i];
    }
    w_document_copy(out,cursor,wguide+wguide_len);
    {long length=ftell(out);
        if(length<0||(unsigned long)length>=W_GUIDE)return w_fail("next_guide_capacity","");
    }
    return ferror(out)||wfailure?w_fail("guide_write",""):0;
}
int w_generate(const char *config,const char *registry,const char *output)
{
    FILE *out;int a,b;
    if(w_prepare(config)||w_check_registry(registry)||w_output_open(output,&out))return 1;
    a=w_render_guide(out);b=w_output_close(out,output);if(a||b)return 1;
    if(w_commit_output(output))return 1;
    printf("GENERATE|functions=%d|issued_homes=%d|model_content=0\n",wnfunc,wnhome);return 0;
}

/* Module: walk_audit.c */

int w_audit(const char *config,const char *registry,const char *guide)
{
    FILE *expected,*actual;int same,a,b;
    if(w_prepare(config)||w_check_registry(registry))return 1;
    expected=tmpfile();actual=fopen(guide,"rb");
    if(!expected||!actual){if(expected)fclose(expected);if(actual)fclose(actual);return w_fail("audit_input",guide);}
    if(w_render_guide(expected)||fflush(expected)){fclose(expected);fclose(actual);return 1;}
    rewind(expected);same=w_equal(expected,actual);a=fclose(expected);b=fclose(actual);
    if(a||b)return w_fail("audit_read",guide);
    if(!same)return w_fail("guide_registry_or_template_mismatch",guide);
    printf("AUDIT|source_registry_bytes=PASS|registry_guide_bytes=PASS|functions=%d|unresolved_calls=%d\n",wnfunc,wunknown);return 0;
}

/* Module: walk_reader_key.c */
#include <string.h>
#include <stdlib.h>
#include <inttypes.h>

/* The architectural names are data carried from the accepted guide. They
 * never assign physical homes or establish semantic function bindings. */
static char sections[15][W_PATH],subs[15][26][W_PATH];
static struct {int s,t,h;} refs[W_FUNCS*4];
static int nrefs,have_key;
static char origin[24];
static char reference[W_GUIDE];
static const char *key_begin="<!-- READER_KEY:BEGIN -->\n";
static const char *key_end="<!-- READER_KEY:END -->";

static int span(char *dest,size_t cap,const char *a,const char *b)
{
    size_t n;
    while(a<b&&*a==' ')++a;
    while(b>a&&b[-1]==' ')--b;
    n=(size_t)(b-a);
    if(!n||n>=cap||memchr(a,'|',n)||memchr(a,'\n',n)||memchr(a,'\r',n))
        return w_fail("reader_key_field","");
    memcpy(dest,a,n);dest[n]=0;return 0;
}
static int section_id(const char *id)
{return strlen(id)==1&&id[0]>='A'&&id[0]<='O'?id[0]-'A':-1;}
static int scope_id(const char *id,int *s,int *t)
{
    if(strlen(id)!=2||id[0]<'A'||id[0]>'O'||id[1]<'a'||id[1]>'z')return w_fail("reader_scope",id);
    *s=id[0]-'A';*t=id[1]-'a';return 0;
}
static int home_id(const char *id)
{
    int i,n;
    if(strlen(id)!=5||id[2]!='-'||id[3]<'0'||id[3]>'9'||id[4]<'0'||id[4]>'9')return -1;
    n=(id[3]-'0')*10+id[4]-'0';
    for(i=0;i<wnhome;++i)if(wh[i].section==id[0]&&wh[i].subsection==id[1]&&wh[i].number==n)return i;
    return -1;
}
static int add_ref(int s,int t,const char *address,const char *label,const char *file)
{
    int i,h=home_id(address);
    if(s<0||t<0||!subs[s][t][0]||h<0)return w_fail("reader_reference_address",address);
    if(strcmp(wh[h].label,label)||strcmp(wh[h].file,file))return w_fail("reader_reference_identity",address);
    for(i=0;i<nrefs;++i)if(refs[i].s==s&&refs[i].t==t&&refs[i].h==h)return w_fail("duplicate_reader_reference",address);
    if(nrefs==(int)(sizeof refs/sizeof refs[0]))return w_fail("reader_reference_capacity","");
    refs[nrefs].s=s;refs[nrefs].t=t;refs[nrefs++].h=h;return 0;
}
static int serialized(const char *a,const char *b)
{
    const char *p=a;int seen_origin=0;
    while(p<b){const char *e=memchr(p,'\n',(size_t)(b-p));char line[W_DECL],*part[6],*q;int n=0,s,t;
        size_t len;if(!e)e=b;len=(size_t)(e-p);
        if(!len||len>=sizeof line)return w_fail("reader_record_length","");
        memcpy(line,p,len);line[len]=0;q=line;
        while(q&&n<6){char *next=strchr(q,'|');part[n++]=q;if(next)*next++=0;q=next;}
        if(q)return w_fail("reader_record_fields","");
        if(n==2&&!strcmp(part[0],"READER_ORIGIN")){
            size_t k;if(seen_origin++||strlen(part[1])!=16)return w_fail("reader_origin","");
            for(k=0;k<16;++k)if(!strchr("0123456789ABCDEF",part[1][k]))return w_fail("reader_origin","");
            if(w_copy(origin,sizeof origin,part[1]))return 1;
        }else if(n==3&&!strcmp(part[0],"SECTION_KEY")){
            s=section_id(part[1]);if(s<0||sections[s][0]||!part[2][0])return w_fail("reader_section_key",part[1]);
            if(w_copy(sections[s],W_PATH,part[2]))return 1;
        }else if(n==3&&!strcmp(part[0],"SUBSECTION_KEY")){
            if(scope_id(part[1],&s,&t)||subs[s][t][0]||!part[2][0])return w_fail("reader_subsection_key",part[1]);
            if(w_copy(subs[s][t],W_PATH,part[2]))return 1;
        }else if(n==5&&!strcmp(part[0],"SEE_KEY")){
            if(scope_id(part[1],&s,&t)||add_ref(s,t,part[2],part[3],part[4]))return 1;
        }else return w_fail("reader_record_kind",part[0]);
        p=e<b?e+1:e;
    }
    return seen_origin==1?0:w_fail("reader_origin_missing","");
}
static int legacy(const char *a,const char *b)
{
    const char *p=a;int s=-1,t=-1;
    while(p<b){const char *e=memchr(p,'\n',(size_t)(b-p));size_t n;
        if(!e)e=b;
        n=(size_t)(e-p);
        if(n>8&&!memcmp(p,"| ",2)&&p[2]>='A'&&p[2]<='O'&&!memcmp(p+3," | ",3)){
            const char *q=memchr(p+6,'|',(size_t)(e-p-6));int k=p[2]-'A';
            if(!q||sections[k][0]||span(sections[k],W_PATH,p+6,q))return w_fail("reader_legacy_section","");
        }else if(n>10&&!memcmp(p,"- `",3)&&p[5]=='`'){
            char id[3];const char *q,*r;id[0]=p[3];id[1]=p[4];id[2]=0;
            if(scope_id(id,&s,&t))return 1;
            q=strstr(p," — ");if(!q||q>=e)return w_fail("reader_legacy_scope",id);q+=strlen(" — ");
            r=strstr(q," — ");if(!r||r>=e||subs[s][t][0]||span(subs[s][t],W_PATH,q,r))return w_fail("reader_legacy_scope",id);
        }else if(n>14&&!memcmp(p,"  - `[See ",10)){
            char address[16],label[W_NAME],file[W_PATH];const char *q=strstr(p,"]` "),*r,*f,*z;
            if(!q||q>=e||span(address,sizeof address,p+10,q))return 1;
            r=strstr(q+3," — `");if(!r||r>=e||span(label,sizeof label,q+3,r))return 1;
            f=r+strlen(" — `");z=memchr(f,'`',(size_t)(e-f));
            if(!z||span(file,sizeof file,f,z)||add_ref(s,t,address,label,file))return 1;
        }
        p=e<b?e+1:e;
    }return 0;
}
int w_reader_load(void)
{
    const char *doc=wguide,*a,*b;size_t length=wguide_len;int s,t,count=0;
    if(wreader_reference[0]){
        if(strstr(wguide,key_begin))return w_fail("reader_key_already_carried_remove_bootstrap_reference","");
        if(w_read(wreader_reference,reference,sizeof reference,&length))return 1;
        doc=reference;
    }
    a=strstr(doc,key_begin);
    if(a){
        b=strstr(a,key_end);
        if(!b||strstr(b+strlen(key_end),key_begin)||strstr(b+strlen(key_end),key_end))return w_fail("reader_key_boundary","");
        if(serialized(a+strlen(key_begin),b))return 1;
    }else{
        if(strstr(doc,key_end))return w_fail("reader_key_boundary","");
        a=strstr(doc,"Hardened Second-Pass Logical Reference Index:");
        if(!a){if(wreader_reference[0])return w_fail("reader_reference_has_no_key",wreader_reference);return 0;}
        b=strstr(a,"<!-- GENERATED:HEADING_INDEX:END -->");if(!b)return w_fail("reader_legacy_boundary","");
        if(legacy(a,b))return 1;
        if(snprintf(origin,sizeof origin,"%016" PRIX64,w_pin(doc,length))<0)return 1;
    }
    for(s=0;s<15;++s){if(sections[s][0])++count;
        for(t=0;t<26;++t)if(subs[s][t][0]&&!sections[s][0])return w_fail("reader_scope_without_section","");
    }
    if(count!=12&&count!=15)return w_fail("reader_incomplete_key","");
    for(s=0;s<15;++s)if((s<10||s==12||s==13)&&!sections[s][0])return w_fail("reader_missing_section_key","");
    for(t=0;t<9;++t)if(!subs[6][t][0])return w_fail("reader_incomplete_mcp_key","");
    have_key=1;return 0;
}
void w_reader_records(FILE *out)
{
    int s,t,i;if(!have_key)return;
    fprintf(out,"READER_ORIGIN|%s\n",origin);
    for(s=0;s<15;++s)if(sections[s][0])fprintf(out,"SECTION_KEY|%c|%s\n",'A'+s,sections[s]);
    for(s=0;s<15;++s)for(t=0;t<26;++t)if(subs[s][t][0])fprintf(out,"SUBSECTION_KEY|%c%c|%s\n",'A'+s,'a'+t,subs[s][t]);
    for(s=0;s<15;++s)for(t=0;t<26;++t)for(i=0;i<nrefs;++i)if(refs[i].s==s&&refs[i].t==t){w_home *h=&wh[refs[i].h];
        fprintf(out,"SEE_KEY|%c%c|%c%c-%02d|%s|%s\n",'A'+s,'a'+t,h->section,h->subsection,h->number,h->label,h->file);
    }
}
void w_reader_link(FILE *out,int h)
{
    if(wh[h].current<0)fprintf(out,"`%c%c-%02d`",wh[h].section,wh[h].subsection,wh[h].number);
    else fprintf(out,"[%c%c-%02d](#function_%c%c_%02d)",wh[h].section,wh[h].subsection,wh[h].number,wh[h].section,wh[h].subsection,wh[h].number);
}
static void scopes(FILE *out,int s)
{
    int t,i;
    fputs("| Service / design slot | Retained meaning | Current-address references |\n|---|---|---|\n",out);
    for(t=0;t<26;++t)if(subs[s][t][0]){int found=0;
        fprintf(out,"| %c%c | %s | ",'A'+s,'a'+t,subs[s][t]);
        for(i=0;i<nrefs;++i)if(refs[i].s==s&&refs[i].t==t){int h=refs[i].h;
            if(found++)fputs(", ",out);
            w_reader_link(out,h);
            if(wh[h].current<0)fputs(" (prior only)",out);
        }
        if(!found)fputs("[SOURCE_BINDING_OPEN]",out);
        fputs(" |\n",out);
    }fputc('\n',out);
}
void w_reader_section(FILE *out,int s)
{
    if(sections[s][0]){
        fprintf(out,"**Retained architectural name: %s.** [Section key](#section_key).\n\n",sections[s]);
        if(s==6){fputs("MCP service key (Ga through Gi). Links open the retained physical function records.\n\n",out);scopes(out,s);}
    }else fputs("Architectural meaning: [SECTION_MEANING_OPEN]. [Section key](#section_key).\n\n",out);
}
void w_reader_key(FILE *out)
{
    int s,t,h;
    fputs("<a id=\"section_key\"></a>\n\n**Section key — retained architectural names**\n\n",out);
    fputs("The accepted outline names the architectural jobs below. Chapter VI keeps each function at its issued file address. The current file grouping and architectural jobs still require reconciliation: for example, a function addressed Fa belongs to the file under physical SubSection Fa, while design slot Fa names WORKING MEMORY. Read a service's See reference to reach its current function record.\n\n",out);
    fputs("| Section | Retained architectural name | Current source functions at issued homes |\n|---|---|---:|\n",out);
    for(s=0;s<15;++s)if(wsections[s][0]||sections[s][0]){int n=0;
        for(h=0;h<wnhome;++h)if(wh[h].section=='A'+s&&wh[h].current>=0)++n;
        fprintf(out,"| [%c](#section_%c) | %s | %d |\n",'A'+s,'A'+s,sections[s][0]?sections[s]:"[SECTION_MEANING_OPEN]",n);
    }
    fputs("\n**MCP — Section G**\n\n",out);scopes(out,6);
    fputs("See references were carried from the accepted outline and checked against filename, issued address, and retained function label. Their identity check establishes where to inspect the source. Service behavior remains a separate review question. [SOURCE_BINDING_OPEN] means the outline supplies no exact reference for that service.\n\n",out);
    fputs("<details>\n<summary>Other architectural subsections</summary>\n\n",out);
    for(s=0;s<15;++s)if(s!=6&&sections[s][0]){int any=0;
        for(t=0;t<26;++t)if(subs[s][t][0])any=1;
        if(any){fprintf(out,"**%c — %s**\n\n",'A'+s,sections[s]);scopes(out,s);}
    }fputs("</details>\n\n",out);
    if(have_key){
        fprintf(out,"Architectural-key source: accepted guide FNV-1a 64 `%s`.\n\n",origin);
        fputs("<details>\n<summary>Machine-readable section key carried into the next update</summary>\n\n```text\n",out);
        fputs(key_begin,out);w_reader_records(out);fputs(key_end,out);fputs("\n```\n\n</details>\n\n",out);
    }
}

/* Module: walk_reader_view.c */
#include <string.h>

static void row(FILE *out,const char *term,const char *meaning)
{fprintf(out,"| %s | %s |\n",term,meaning);}
static void link_function(FILE *out,int f)
{
    if(wn[f].home>=0)w_reader_link(out,wn[f].home);else fputs("OPEN",out);
    fprintf(out," **%s** — `%s`",wn[f].name,wf[wn[f].file].path);
}
void w_reader_tree(FILE *out)
{
    static int parent[W_FUNCS],child[W_FUNCS],next[W_FUNCS],last[W_FUNCS],order[W_FUNCS];
    static int stack[W_FUNCS],cursor[W_FUNCS];
    int i,f,k,top=0,reached=0,printed=0;
    for(i=0;i<wnfunc;++i){parent[i]=child[i]=next[i]=last[i]=-1;order[i]=-1;}
    for(i=0;i<wnfunc;++i){
        if(wn[i].flow<0||wn[i].flow>=wnfunc||order[wn[i].flow]>=0){w_fail("reader_flow_order","");return;}
        order[wn[i].flow]=i;
        if(wn[i].depth>=0)++reached;
    }
    for(k=0;k<wnfunc;++k){f=order[k];
        if(wn[f].depth<=0)continue;
        for(i=0;i<wncall;++i)if(wc[i].to==f&&wn[wc[i].from].depth==wn[f].depth-1){int p=wc[i].from;
            if(parent[f]<0||wn[p].flow<wn[parent[f]].flow)parent[f]=p;
        }
        if(parent[f]<0){w_fail("reader_tree_missing_parent",wn[f].name);return;}
        if(last[parent[f]]>=0)next[last[parent[f]]]=f;else child[parent[f]]=f;
        last[parent[f]]=f;
    }
    fputs("<a id=\"function_tree\"></a>\n\n**Simple function tree — start at the entry point**\n\n",out);
    fprintf(out,"This tree shows all %d functions reached through resolved direct calls. Each child is expanded once beneath its first breadth-first parent. Shared calls and recursive calls remain in the complete graph and in each function's callers/callees. Follow an address to open its full record.\n\n",reached);
    fputs("- ",out);link_function(out,wroot_function);fputs(" (entry point)\n",out);++printed;
    stack[0]=wroot_function;cursor[0]=child[wroot_function];
    while(top>=0){
        f=cursor[top];
        if(f<0){--top;continue;}
        cursor[top]=next[f];
        for(i=0;i<=top;++i)fputs("  ",out);
        fputs("- ",out);link_function(out,f);fputc('\n',out);++printed;
        if(top+1>=W_FUNCS||parent[f]!=stack[top]){w_fail("reader_tree_structure","");return;}
        ++top;stack[top]=f;cursor[top]=child[f];
    }
    if(printed!=reached){w_fail("reader_tree_coverage","");return;}
    fprintf(out,"\n<details>\n<summary>%d other source functions — outside this resolved entry-point tree</summary>\n\n",wnfunc-reached);
    fputs("These functions remain in the source inventory. Each requires its own caller, callback, macro, build, or tool-entry investigation.\n\n",out);
    for(k=0;k<wnfunc;++k){f=order[k];if(wn[f].depth<0){fputs("- ",out);link_function(out,f);fputc('\n',out);}}
    fputs("\n</details>\n\n",out);
}
static void worked_example(FILE *out)
{
    int i,f=-1;
    for(i=0;i<wnfunc;++i)if(!strcmp(wf[wn[i].file].path,"src/shakti_tablet.c")&&!strcmp(wn[i].name,"shakti_tablet_audit"))f=i;
    if(f<0)return;
    fputs("<a id=\"tablet_example\"></a>\n\n**Worked example — shakti_tablet_audit**\n\n",out);
    fputs("Full record: ",out);link_function(out,f);fputs(".\n\n",out);
    if(wn[f].pin!=UINT64_C(0xA3559F1867D51CD4)){
        fputs("[EXAMPLE_REVIEW_REQUIRED] The function source has changed since this explanation was checked. Use the current source record for its behavior.\n\n",out);return;
    }
    fputs("This function checks a loaded lesson tablet's artifacts and fills an audit result. For each stone it checks the text/filename contract, written-text artifact, sound artifacts, and visual SVG. It adds each stone's score to the tablet score. The foundation_ascii level counts three required checks; the other levels count four, including sound.\n\n",out);
    fputs("| Item | Meaning in this function |\n|---|---|\n",out);
    row(out,"`tablet` — input 1","The loaded tablet and its stones, read through a const pointer.");
    row(out,"`artifact_root` — input 2","The directory used to form paths to the artifacts being checked.");
    row(out,"`audit` — input 3","Caller-provided result storage. The function clears it, fills stone_count and each stone's check results, and accumulates score.");
    row(out,"`return 0`","A tablet, root-directory, or audit pointer is null, or the tablet is marked unloaded.");
    row(out,"`return 1`","The function reached the end of its checking loop. Individual artifact results and scores are in audit.");
    row(out,"`audit->stone_count =`","The recorded write-site prefix. The full source statement copies tablet->stone_count into audit->stone_count.");
    row(out,"`stone_audit->text_ok =`","A write through stone_audit, which the source sets to &audit->stones[index]. Its type/alias relation remains unresolved in the general extractor.");
    row(out,"`index =` / `passed ++`","Local bookkeeping: position in the stone array and the number of passed checks.");
    row(out,"`memset` / `strcmp` with state open","These are C library calls; this inventory has no source definition for them. Their call sites and arguments remain recorded.");
    fputs("| Callers | ",out);
    {int found=0,j;
        for(i=0;i<wncall;++i)if(wc[i].to==f){int duplicate=0;
            for(j=0;j<i;++j)if(wc[j].to==f&&wc[j].from==wc[i].from)duplicate=1;
            if(!duplicate){if(found++)fputs("; ",out);fprintf(out,"%s in %s",wn[wc[i].from].name,wf[wn[wc[i].from].file].path);}
        }
        if(!found)fputs("[RESOLVED_CALLER_OPEN]",out);
    }
    fputs(" |\n",out);
    fputs("\nThis explanation was checked against the complete function bytes with FNV-1a 64 pin `A3559F1867D51CD4`. The generator withdraws the behavior explanation when those bytes change.\n\n",out);
}
void w_reader_glossary(FILE *out)
{
    fputs("<a id=\"reading_key\"></a>\n\n**Start here — how to read this guide**\n\n",out);
    fputs("[Section key and MCP](#section_key) · [Simple function tree](#function_tree) · [XML and number key](#xml_key) · [Tablet audit example](#tablet_example) · [Complete heading index](#heading_index)\n\n",out);
    fputs("Read the section key to choose a job, follow a function address to its record, then use inputs, outputs, callers, and callees to follow the connection. The detailed records and source bytes remain available later in the guide.\n\n",out);
    fputs("<details>\n<summary>Chapter reading order</summary>\n\n| Where | What you use it for |\n|---|---|\n",out);
    row(out,"Chapter I","Handling instructions and the controlling structure.");
    row(out,"Chapter II","This reading key, architectural section names, function tree, heading index, and complete call graph.");
    row(out,"Chapter III","Tyler's rules and laws, retained in their controlling location.");
    row(out,"Chapter IV","Five-field file registry: path, current section/subsection, function count, and architectural See homes.");
    row(out,"Chapter V","One declaration and source pin per function.");
    row(out,"Chapter VI","Full function records and exact function code at their issued addresses.");
    row(out,"Chapter VII","The same function records organized alphabetically within each issued home.");
    row(out,"Chapter VIII","Tyler's task list.");
    row(out,"Chapter IX","Schemas and templates.");
    row(out,"Chapter X","Complete inventoried source-file bytes.");
    row(out,"Chapter XI","The carried amendment log and the current generated source receipt.");
    fputs("\n</details>\n\n<a id=\"xml_key\"></a>\n\n<details>\n<summary>XML and number key — every generated function field</summary>\n\n",out);
    fputs("The meanings in this table apply throughout the generated function records.\n\n| Element or number | Definition |\n|---|---|\n",out);
    row(out,"`function_record`","Outer workbook package containing the retained guide label, source declaration, and the detailed function object.");
    row(out,"`file_name` / `filename`","Exact repository-relative source path. In calls/callers it identifies the target/caller file. In the XML inventory, filename id groups a file's function objects.");
    row(out,"`function_name`","Retained guide label. Older labels may include a file suffix used to distinguish repeated names.");
    row(out,"`function` / its `name`","The function object and the exact C identifier parsed from the declaration. This source name can differ from the retained guide label.");
    row(out,"`return_type`","Declared C return type. The same type appears inside outputs.");
    row(out,"`declaration`","Return type, exact source function name, and declared parameters, with spacing normalized by the tokenizer.");
    row(out,"`address`, e.g. `Ao-15`","Issued document home: Section A, SubSection o, function number 15. It comes from the previous guide and stays fixed across updates. Read the file's subsection heading for its actual source ownership.");
    row(out,"`depth`","Shortest resolved-direct-call distance from the configured root. Root = 0; its callees = 1; their newly reached callees = 2. A value of -1 means no path was established by this walk.");
    row(out,"`flow_order`","Zero-based breadth-first inventory position. Reached functions come first in call-site discovery order; other definitions follow in source-file/declaration order. This is generated traversal order; execution order requires the C control flow.");
    row(out,"`inputs` / `input`","The declared parameters received by the function. A pointer parameter can provide readable input, writable result storage, or both; its source use establishes the direction.");
    row(out,"`ordinal`","One-based position. Input ordinal 3 is the third parameter; argument ordinal 3 is the third value expression supplied at a call.");
    row(out,"Input `name` / `type`","Parameter identifier and declared C type. The inventory preserves spelling and pointer qualifiers.");
    row(out,"`outputs` / `output id=return`","The declared return channel. Writes through parameters or other storage appear separately as effects.");
    row(out,"`kind=declared_return` / `no_value`","A declared returned value / a void return with no returned value.");
    row(out,"`effects` / `effect`","Lexically recorded return or write sites inside this function. Local variable updates and externally visible writes share this list; determining ownership can require alias analysis.");
    row(out,"`return_site_14232`","A return statement beginning at byte offset 14232 in the original source file. The offset supplies the site identity.");
    row(out,"`write_site_14291`","An assignment or increment/decrement site beginning at byte offset 14291. This site ID can change when earlier source bytes change.");
    row(out,"Effect `type=unresolved`","The extractor retained the write but has not resolved its C type. The word describes extraction knowledge at that site.");
    row(out,"`expression`","For a return, the normalized return statement. For a write, the recorded left side and write operator, or increment/decrement prefix. Read the full source for the assigned value.");
    row(out,"`start` / `end`","Zero-based byte offsets into the original source file. start is inclusive and end is exclusive: [start,end). Their difference is the recorded span's byte length.");
    row(out,"`callees` / `call`","Functions this function invokes. Repeated calls remain separate entries because each has its own source site.");
    row(out,"Call `site`","Byte offset in the file containing the calling function.");
    row(out,"`state=direct_definition`","The resolver identified one function definition in the admitted source inventory.");
    row(out,"`state=open`","The target remains external, macro-based, indirect, or otherwise unresolved. C library calls such as memset and strcmp can have this state.");
    row(out,"Call `name` / `filename`","The invoked target token and, when resolved, the exact file containing its definition.");
    row(out,"`argument`","The actual expression passed at that call site. It is paired with the receiving parameter by ordinal.");
    row(out,"`callers` / `caller`","Functions that invoke this function. Each caller contains its own filename, source name, and call-site byte offset.");
    row(out,"`source_pin algorithm=fnv1a64`","A deterministic 64-bit change marker calculated from this function's exact source bytes and printed as sixteen hexadecimal digits. Audit also compares the exact source bytes.");
    row(out,"`&gt;`, `&lt;`, `&amp;`, `&quot;`","XML encodings for greater-than, less-than, ampersand, and quotation mark. For example, -&gt; represents the C member-access operator ->.");
    row(out,"`int`, `unsigned long`, `size_t`","C integer type; unsigned long integer type; unsigned type used for object sizes and array indexes. C defines their platform-dependent ranges.");
    row(out,"`char`, `void`, `_t`","Character-sized C type; no returned value in a void-return declaration; a conventional suffix on a typedef name whose definition is in the source/header.");
    row(out,"`*`, `const T *`, `&value`","Pointer to an object; pointer through which the T object is read-only; address of value. The audit parameter is a pointer to writable caller-provided result storage.");
    row(out,"`object.member`, `pointer->member`, `[index]`","Select a struct member; select a member through a pointer; select an array element.");
    row(out,"`=`, `++`, `return`","Assignment; increment by one; return control and any declared result to the caller.");
    row(out,"`[PROPOSED]` in a heading","A retained placement label from the accepted earlier guide. The updater carries the heading unchanged.");
    row(out,"`PRIOR_ONLY / RESERVED`","The earlier guide issued this identity an address, but the current source snapshot lacks that function. The address remains reserved.");
    row(out,"`[See ADDRESS]` / address link","A cross-reference to a function's existing home. Its architectural association comes from the supplied outline; its source identity is checked mechanically.");
    row(out,"`[SOURCE_BINDING_OPEN]` / `[SECTION_MEANING_OPEN]`","The supplied architectural key lacks a function reference / lacks a section meaning. The item stays visible for review.");
    row(out,"Complete graph IDs `f42` / `x67`","Internal rendering identifiers for a function / unresolved call site. Read the node's printed name and address for identity.");
    row(out,"Complete graph arrows","Solid: resolved call; dotted: unresolved target. An edge's numeric label is its source byte offset. A loop records a recursive call.");
    row(out,"Function numbers / subsection letters","Issued within their original containing headings. Alphabetic display order in Chapter VII preserves these numbers.");
    fputs("\n</details>\n\n**Source review items**\n\n",out);
    fputs("Declared types identify the interface. Pointer outputs, local aliases, macro expansion, conditional builds, and runtime call paths need the associated source evidence. The separate findings retain these open questions. A byte-identical guide rebuild establishes repeatable documentation; section closure also requires the behavior checks in its work order.\n\n",out);
    worked_example(out);
}

/* Module: walk_document.c */
#include <string.h>

/* Document migration is a fixed recipe. Source facts and issued homes remain
 * owned by the inventory and placement modules. */
const char *wchapters[11];
static const char *doc_titles[]={
    "CHAPTER I — INTRODUCTION", "CHAPTER II — TABLE OF CONTENTS",
    "CHAPTER III — TYLER-RESERVED RULES AND LAWS", "CHAPTER IV — FILE REGISTRY",
    "CHAPTER V — DEFINITIONS AND ELEMENTS", "CHAPTER VI — CURRENT BUILT STRUCTURE",
    "CHAPTER VII — FUNCTION REGISTRY AND JOBS", "CHAPTER VIII — TASK LIST",
    "CHAPTER IX — SCHEMAS AND TEMPLATES", "CHAPTER X — PROJECT FILES",
    "CHAPTER XI — AMENDMENTS | LOG"
};
static const char doc_entry_begin[]="<!-- SUPERVISOR_ENTRY:BEGIN -->\n";
static const char doc_entry_end[]="<!-- SUPERVISOR_ENTRY:END -->\n";
static const char doc_source_begin[]="<!-- SUPERVISION_SOURCE:BEGIN -->\n``````````markdown\n";
static const char doc_source_end[]="\n``````````\n<!-- SUPERVISION_SOURCE:END -->";
static char doc_source[1024UL*1024UL];
static size_t doc_source_size;
static int doc_has_entry,doc_has_source;

static int doc_block(const char *a,const char *b,int chapter_index,
                     const char **first,const char **last)
{
    const char *p=strstr(wguide,a),*q=strstr(wguide,b);
    *first=NULL;*last=NULL;
    if(!p&&!q)return 0;
    if(!p||!q||q<p||strstr(p+strlen(a),a)||strstr(q+strlen(b),b))
        return w_fail("document_block_pair",a);
    if(p<wchapters[chapter_index]||q+strlen(b)>wchapters[chapter_index+1])
        return w_fail("document_block_chapter",a);
    *first=p+strlen(a);*last=q;return 0;
}

int w_document_load(void)
{
    const char *p=wguide,*limit=wguide+wguide_len,*a,*b;
    int count=0;size_t fence=0;char fence_char=0;
    while(p<limit){
        const char *e=memchr(p,'\n',(size_t)(limit-p)),*s=p,*q;
        size_t run=0;int indent=0;
        if(!e)e=limit;
        while(s<e&&*s==' '&&indent<4){++s;++indent;}
        if(indent<4&&s<e&&(*s=='`'||*s=='~')){
            char c=*s;q=s;while(q<e&&*q==c){++q;++run;}
            if(!fence&&run>=3){fence=run;fence_char=c;}
            else if(fence&&c==fence_char&&run>=fence){
                while(q<e&&(*q==' '||*q=='\t'||*q=='\r'))++q;
                if(q==e){fence=0;fence_char=0;}
            }
        }else if(!fence&&s==p&&s<e&&*s=='#'){
            int level=0;q=s;while(q<e&&*q=='#'){++q;++level;}
            if(q<e&&*q==' ')++q;
            if((size_t)(e-q)>=8&&!memcmp(q,"CHAPTER ",8)){
                size_t n;
                if(count==11||level<1||level>2)return w_fail("locked_chapter_level_or_duplicate","");
                n=strlen(doc_titles[count]);
                if((size_t)(e-q)!=n||memcmp(q,doc_titles[count],n))
                    return w_fail("locked_chapter_title_or_order",doc_titles[count]);
                wchapters[count++]=p;
            }
        }
        p=e<limit?e+1:e;
    }
    if(fence)return w_fail("unclosed_document_fence","");
    if(count!=11)return w_fail("locked_chapter_count","");
    if(doc_block(doc_entry_begin,doc_entry_end,0,&a,&b))return 1;
    doc_has_entry=a!=NULL;
    if(doc_block(doc_source_begin,doc_source_end,8,&a,&b))return 1;
    doc_has_source=a!=NULL;
    if(a){
        if(wsupervision_reference[0])return w_fail("supervision_reference_already_embedded_remove_config_field","");
        doc_source_size=(size_t)(b-a);
        if(doc_source_size>=sizeof doc_source)return w_fail("supervision_source_capacity","");
        memcpy(doc_source,a,doc_source_size);doc_source[doc_source_size]=0;
    }else if(wsupervision_reference[0]){
        if(w_read(wsupervision_reference,doc_source,sizeof doc_source,&doc_source_size))return 1;
        if(!doc_source_size)return w_fail("empty_supervision_reference","");
        if(strstr(doc_source,"``````````")||strstr(doc_source,"<!-- SUPERVISION_SOURCE:")||strstr(doc_source,"<!-- SUPERVISOR_ENTRY:"))
            return w_fail("supervision_reference_reserved_delimiter","");
    }
    return 0;
}

void w_document_records(FILE *out)
{
    fputs("DOCUMENT_FORMAT|chapters_h1|1\n",out);
    if(doc_source_size){
        fprintf(out,"SUPERVISION_SOURCE|%lu|",(unsigned long)doc_source_size);
        w_field(out,doc_source);fputc('\n',out);
    }
}

static void doc_entry(FILE *out)
{
    fputc('\n',out);fputs(doc_entry_begin,out);
    fputs("## Start here — one section at a time\n\n"
          "This master is the single reading document. Use heading navigation for Chapters I through XI. "
          "Chapter II contains the section key, the Ga–Gi MCP key, XML definitions, and the simple function tree. "
          "Chapter VI contains the source-backed function records at their existing addresses. "
          "Chapter IX carries the complete earlier supervision specification and maps when supplied.\n\n"
          "### What can run now\n\n"
          "The native program runs four operations: inventory, decide, generate, and audit. "
          "These operations prepare and verify the complete guide from the selected source snapshot. "
          "Project execution, independent human or model review, and remote promotion have separate evidence requirements. "
          "A successful guide audit establishes agreement between its inputs and generated bytes.\n\n"
          "### Short instruction to the supervisor\n\n"
          "1. Read this entry, the complete controlling outline and rules, the last accepted receipt, and the current section. "
          "Let the program read the complete source and prior guide. Preserve the recorded baseline.\n"
          "2. Run inventory. Run decide for the active physical section or subsection; start with Aa for src/main.c in the supplied workbook. "
          "Architectural Section G is the MCP key; follow its exact See references to physical homes.\n"
          "3. Select the first unresolved generated question. Read the complete producer and receiver functions and receiving declaration. "
          "Record filename, function, receiving input ordinal and type, proposed output, meaning, units, ownership, lifetime, and source evidence. "
          "A zero-candidate question can originate outside a return channel, including external arguments or pointer/state flow; trace its actual origin. "
          "Keep UNKNOWN beside a precise next question.\n"
          "4. Define one bounded work order using F01 in Chapter IX. Use KEEP, REMOVE, or RELOCATE only with the recorded authority. "
          "Record every contributor. Have an independent reviewer check the instruction before implementation.\n"
          "5. Bind the candidate, full diff, tests, documentation, and reviews to the same exact content identity. "
          "Regenerate inventory after changes; generate the guide twice from identical inputs; compare and audit it.\n"
          "6. Have a reviewer outside the author set check the candidate and the supervisor's closure. "
          "Close only the stated scope after its required behavior and preservation checks pass. "
          "Keep the accepted complete guide as the next previous_guide.\n\n",out);
    fputs("### Independent review and enforcement\n\n"
          "Tyler's rule applies to every role: each authored object requires a separate reviewer. "
          "AUTHOR_IDS lists all contributors to that object, including instruction and checker changes. "
          "The host must verify ACTOR_ID, PROVIDER, MODEL_ID, SESSION_ID, and PRINCIPAL against authenticated assignments. "
          "The reviewer must be outside AUTHOR_IDS and have a different model identity and session from its authors. "
          "Changing roles or labels preserves authorship. Any edit after review requires review of the changed candidate.\n\n"
          "Current activation state: the C program enforces source/registry/guide consistency and chapter structure. "
          "Authenticated role separation, write-path isolation, receipt freshness, required behavior tests, and promotion gates "
          "require demonstrated host enforcement before unattended source changes. Use the S09.3 activation exercises in Chapter IX. "
          "Until that evidence exists, the prepared workflow supports inventory and review; source-change authorization remains with Tyler.\n\n"
          "### Resume record\n\n"
          "Record this beside the section's accepted receipt. These fields describe observed work; "
          "a filled form acquires authority only through the independently checked host receipt.\n\n"
          "```text\n"
          "WORK_ID=[existing task identity]\nREVISION=[instruction revision]\n"
          "ACTIVE_SCOPE=[one physical section or subsection]\n"
          "BASE_COMMIT=[exact source revision]\nGUIDE_PIN=[accepted complete guide identity]\n"
          "AUTHOR_IDS=[all contributors to the reviewed object]\nREVIEWER_ID=[verified independent actor]\n"
          "CANDIDATE_ID=[exact code and documentation object]\n"
          "LAST_ACCEPTED_RECEIPT=[verified predecessor]\n"
          "LAST_COMPLETED_GATE=[observed gate]\nOPEN_FINDINGS=[exact unresolved identities]\n"
          "NEXT_ACTION=[one operation, actor, inputs, and expected output]\n"
          "STATUS=[PASS, FAIL, UNKNOWN, or HOLD for the named scope]\n```\n\n",out);
    fputs("### Compile and run the C file\n\n"
          "The single-file distribution is shakti_walk.c. Compile it with:\n\n"
          "```text\ncc -std=c99 -pedantic -Wall -Wextra -Werror -O2 shakti_walk.c -o shakti_walk\n```\n\n"
          "Create source_walk.conf with the six required fields below. Paths are interpreted from the process's working directory; "
          "absolute paths are suitable. Obtain repository_tree and all tracked C/header files from the same source revision. "
          "The preserved source revision is recorded in Chapter XI.\n\n"
          "```text\nsource_root=[local source checkout]\nprevious_guide=[this accepted complete master]\n"
          "repository_tree=[complete recursive Git tree JSON]\nsource_revision=[exact revision]\n"
          "root_file=src/main.c\nroot_name=SHAKTI_APP_MAIN\n```\n\n"
          "The root_name above is the actual source declaration in the supplied snapshot. "
          "The default preprocessor branch names its executable entry main. "
          "Create a fresh output directory for each run and keep the input guide unchanged.\n\n"
          "```text\n./shakti_walk inventory source_walk.conf registry.txt functions.xml findings.txt\n"
          "./shakti_walk decide source_walk.conf registry.txt aa_questions.txt Aa\n"
          "./shakti_walk generate source_walk.conf registry.txt guide_v1.md\n"
          "./shakti_walk generate source_walk.conf registry.txt guide_v2.md\n"
          "diff guide_v1.md guide_v2.md\n"
          "./shakti_walk audit source_walk.conf registry.txt guide_v1.md\n```\n\n"
          "An empty diff and a successful audit are required for the document result. "
          "findings.txt retains unresolved source facts for investigation. "
          "The compiler and diff are host commands. The C runtime uses standard file I/O, fixed-capacity storage, "
          "and four explicit operations.\n\n"
          "### Variable key\n\n"
          "source_root: the directory containing the selected source files. "
          "previous_guide: the entire accepted master used as template. "
          "repository_tree: the complete nontruncated recursive Git tree for source_revision. "
          "source_revision: the explicit source commit. root_file and root_name: the exact entry file and declaration. "
          "ACTIVE_SCOPE: one issued physical section or subsection. "
          "input ordinal: parameter position counted from one. output identity: a declared return channel or identified source effect. "
          "CANDIDATE_ID: the content identity shared by the diff, tests, and reviews. "
          "LAST_ACCEPTED_RECEIPT: the independently verified predecessor used to resume.\n\n",out);
    fputs(doc_entry_end,out);fputc('\n',out);
}

static void doc_reference(FILE *out)
{
    fputs("\n## Preserved supervision specification and map sources\n\n"
          "The source below is retained byte for byte for provenance and complete forms F01–F05. "
          "It includes dated preparation receipts and earlier role suggestions. "
          "The current starting procedure is in Chapter I; current source facts are generated in Chapters IV–VII and X. "
          "Apply Tyler's latest role assignments and require actual evidence for every activation gate.\n\n"
          "<details>\n<summary>Read the complete earlier supervision specification, forms, and maps</summary>\n\n",out);
    fputs(doc_source_begin,out);fwrite(doc_source,1,doc_source_size,out);
    fputs(doc_source_end,out);fputs("\n\n</details>\n\n",out);
}

void w_document_copy(FILE *out,const char *first,const char *last)
{
    const char *p=first;
    const char old_order[]="Required reading order: `# TITLE / ## CHAPTER / ### SECTION / #### SubSection / ##### function`.\n";
    while(p<last){
        const char *e=memchr(p,'\n',(size_t)(last-p));int i;
        if(e)++e;else e=last;
        if(p==wchapters[9]&&!doc_has_source&&doc_source_size)doc_reference(out);
        for(i=0;i<11&&p!=wchapters[i];++i){}
        if(i<11){
            if(p[1]=='#')++p;
            fwrite(p,1,(size_t)(e-p),out);
            if(i==0&&!doc_has_entry)doc_entry(out);
        }else if(p>wchapters[0]&&p<wchapters[1]&&(size_t)(e-p)==sizeof old_order-1&&!memcmp(p,old_order,sizeof old_order-1)){
            fputs("Required reading order: `# TITLE / # CHAPTER / ### SECTION / #### SubSection / ##### function`.\n",out);
        }else fwrite(p,1,(size_t)(e-p),out);
        p=e;
    }
}

/* Module: governed_md.c */
#include <string.h>

int main(int argc,char **argv)
{
    if(argc==6&&!strcmp(argv[1],"inventory"))return w_inventory(argv[2],argv[3],argv[4],argv[5]);
    if((argc==5||argc==6)&&!strcmp(argv[1],"decide"))return w_decide(argv[2],argv[3],argv[4],argc==6?argv[5]:"ALL");
    if(argc==5&&!strcmp(argv[1],"generate"))return w_generate(argv[2],argv[3],argv[4]);
    if(argc==5&&!strcmp(argv[1],"audit"))return w_audit(argv[2],argv[3],argv[4]);
    fputs("usage:\n  shakti-walk inventory walk.conf registry.txt functions.xml findings.txt\n  shakti-walk decide walk.conf registry.txt connector_questions.txt [SECTION_OR_SUBSECTION]\n  shakti-walk generate walk.conf registry.txt new_guide.md\n  shakti-walk audit walk.conf registry.txt new_guide.md\n",stderr);
    return 2;
}
