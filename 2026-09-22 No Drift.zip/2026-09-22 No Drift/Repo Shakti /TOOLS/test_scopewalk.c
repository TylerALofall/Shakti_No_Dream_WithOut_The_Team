/* Native fixture producer plus evidence/geometry assertions; no subprocesses.
 * cc -std=c99 -pedantic -Wall -Wextra -Werror -O2 test_scopewalk.c -o test_scopewalk
 * test_scopewalk OUTPUT_DIRECTORY (fresh)
 * Generated .conf files are run by scopewalk separately. */
#define main scopewalk_program_main
#include "scopewalk.c"
#undef main
#include <assert.h>
static void encoded(FILE *o,const char *s)
{for(;*s;++s){unsigned char c=(unsigned char)*s;if(c=='%'||c=='|'||c==','||c<32)fprintf(o,"%%%02X",c);else fputc(c,o);}}
static void fixture(const char *name,int version,int corrupt)
{
    const char *prefix="#include <stdbool.h>\ntypedef enum { FAIL=-1, PASS=7 } Result;\n";
    const char *defs[]={"int receive(int v) { return v; }", "int produce(void) { return 42; }", "bool gate(bool flag) { if(flag) return true; return false; }", "Result choose(int mode) { if(mode) return PASS; return FAIL; }", "void launch(void) { receive(produce()); gate(true); }"};
    const char *names[]={"receive","produce","gate","choose","launch"};
    const char *types[]={"int","int","bool","Result","void"};
    const char *homes[]={"Aa-01","Aa-02","Aa-03","Aa-04","Ab-01"};
    const char *params[]={"int v",NULL,"bool flag","int mode",NULL};
    const char *pn[]={"v",NULL,"flag","mode",NULL};
    char bytes[4096],config_name[PATH];size_t starts[5];FILE *o;int i;size_t len;
    if(version==1)defs[1]="int produce(void) { return 43; }";
    if(version==2){defs[0]="int receive(int w) { return w; }";params[0]="int w";pn[0]="w";}
    copy(bytes,sizeof(bytes),prefix);len=strlen(bytes);
    for(i=0;i<5;++i){starts[i]=len;copy(bytes+len,sizeof(bytes)-len,defs[i]);len+=strlen(defs[i]);bytes[len++]='\n';bytes[len]=0;}
    o=newfile(name);fprintf(o,"FORMAT|shakti_source_walk|1\nSOURCE|fixture-%d\nSECTION_KEY|A|Fixture only\nSUBSECTION_KEY|Aa|Values\nSUBSECTION_KEY|Ab|Caller\nFILE|fixture.c|%lu|%016" PRIX64 "|5\nBYTES|fixture.c|",version,(unsigned long)len,pin(bytes,len)+(corrupt==1));encoded(o,bytes);fputc('\n',o);
    for(i=0;i<5;++i){const char *ret=defs[i],*brace=strchr(defs[i],'{');size_t end=starts[i]+strlen(defs[i]);char decl[256];memcpy(decl,defs[i],(size_t)(brace-defs[i]-1));decl[brace-defs[i]-1]=0;
        fprintf(o,"FN|fixture.c|%s|%s|%s|%lu|%lu|\nAT|fixture.c#%s|unreached|-1|%016" PRIX64 "|%s\n",names[i],types[i],decl,(unsigned long)starts[i],(unsigned long)end,names[i],pin(defs[i],strlen(defs[i])),homes[i]);
        if(params[i]){size_t a=starts[i]+(size_t)(strstr(defs[i],params[i])-defs[i]);fprintf(o,"IN|fixture.c#%s|1|%s|%s|%s|%lu|%lu\n",names[i],pn[i],i==2?"bool":"int",params[i],(unsigned long)a,(unsigned long)(corrupt==2?a:a+strlen(params[i])));}
        fprintf(o,"OUT|fixture.c#%s|return|%s|%s\n",names[i],types[i],i==4?"no_value":"declared_return");
        while((ret=strstr(ret,"return "))!=NULL){const char *semi=strchr(ret,';');size_t a=starts[i]+(size_t)(ret-defs[i]),b=starts[i]+(size_t)(semi-defs[i])+1;fprintf(o,"EFFECT|fixture.c#%s|%lu|%lu|return_site|",names[i],(unsigned long)a,(unsigned long)b);xmln(o,ret,(size_t)(semi-ret)+1);fprintf(o,"|%s\n",types[i]);ret=semi+1;}
        if(i==4){size_t outer=starts[i]+(size_t)(strstr(defs[i],"receive(")-defs[i]);size_t inner=starts[i]+(size_t)(strstr(defs[i],"produce(")-defs[i]);
            fprintf(o,"CALL|fixture.c#launch|%lu|%lu|fixture.c#%s|1|direct_definition\nCALL|fixture.c#launch|%lu|%lu|fixture.c#produce|0|direct_definition\nARG|fixture.c#launch|%lu|1|produce()|int\nBIND|fixture.c#produce|return|fixture.c#receive|1|fixture.c#launch|%lu|%lu|exact_nested_call_and_declared_type\n",(unsigned long)outer,(unsigned long)(outer+18),corrupt==3?"missing":"receive",(unsigned long)inner,(unsigned long)(inner+9),(unsigned long)outer,(unsigned long)outer,(unsigned long)inner);
        }
    }
    closeout(o);
    if(snprintf(config_name,sizeof(config_name),"%s.conf",name)>=(int)sizeof(config_name))stop("test_path",name);
    o=newfile(config_name);fprintf(o,"input_registry=%s/%s\noutput_dir=%s/%s-out\nrender=MASTER,A,Aa\n",output_path,name,output_path,name);if(version)fprintf(o,"previous_registry=%s/base.registry\n",output_path);closeout(o);
}
int main(int argc,char **argv)
{
    char path[PATH];int i,lines=0;
    if(argc!=2)return 2;
    copy(output_path,sizeof(output_path),argv[1]);if(mkdir(output_path,0700))stop("fresh_test_directory",output_path);
    fixture("base.registry",0,0);fixture("changed-return.registry",1,0);fixture("changed-input.registry",2,0);fixture("bad-pin.registry",0,1);fixture("bad-span.registry",0,2);fixture("bad-target.registry",0,3);
    if(snprintf(path,sizeof(path),"%s/base.registry",output_path)>=(int)sizeof(path))stop("test_path",path);
    load(&now,path);load(&before,path);assert(now.nf==5);
    for(i=0;i<5;++i)assert(equal_function(&now.f[i],&before.f[i]));
    before.f[0].type="enum";assert(!equal_function(&now.f[0],&before.f[0]));
    view_model("Aa");geometry();assert(nn==4&&ne==1&&ve[0].binds==1&&ve[0].calls==0);
    for(i=0;i<ne;++i)if(ve[i].direct){assert(same_owner(ve[i].a,ve[i].b));++lines;}
    assert(lines==1);assert(!strcmp(now.f[3].type,"Result"));
    /* Four aligned nodes: the distant edge must use a named connector. */
    nn=4;ne=1;memset(ve,0,sizeof(ve));for(i=0;i<4;++i){vn[i].fi=i;copy(vn[i].key,sizeof(vn[i].key),now.f[i].home);vn[i].x=0;vn[i].y=i*100;vn[i].w=80;vn[i].h=60;}
    assert(intersects(0,3,1));assert(intersects(0,3,2));
    assert(text_lines(NULL,0,0,240,"long_identifier_without_lost_characters",38)==36);
    puts("PASS|native fixtures, exact comparison, typed BIND, obstacle and wrapping checks");return 0;
}
