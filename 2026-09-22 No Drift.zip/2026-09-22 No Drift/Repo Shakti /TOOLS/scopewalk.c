/* Source-walk views: C99, fixed storage, no subprocesses or source writes.
 * cc -std=c99 -pedantic -Wall -Wextra -Werror -O2 scopewalk.c -o scopewalk
 * scopewalk views.conf
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <inttypes.h>
#include <errno.h>
#include <sys/stat.h>

#define ARENA (64u*1024u*1024u)
#define RECORDS 131072
#define FUNCS 4096
#define FILES 512
#define PATH 2048
#define FIELDS 12
#define NODES 4096
#define EDGES 65536
typedef struct { char *v[FIELDS]; int n; } Record;
typedef struct { char id[PATH]; char *file,*name,*type,*decl,*home; size_t start,end; int at,first,last,depth; } Function;
typedef struct { char *path,*bytes,*pin; size_t length; } Source;
typedef struct {
    char arena[ARENA]; size_t length; Record r[RECORDS]; int nr;
    Function f[FUNCS]; int nf; Source s[FILES]; int ns;
    char *section[15],*sub[15][26],*revision;
} Data;
static Data now,before;
static char input_path[PATH],prior_path[PATH],output_path[PATH],render_list[4096]="MASTER,A,Aa,G";
static int have_prior;
static void stop(const char *why,const char *detail)
{fprintf(stderr,"REFUSE|%s|%s\n",why,detail?detail:"");exit(2);}
static void copy(char *dst,size_t cap,const char *s)
{if(strlen(s)>=cap)stop("capacity",s);memcpy(dst,s,strlen(s)+1);}
static unsigned long number(const char *s)
{char *e;unsigned long n;errno=0;n=strtoul(s,&e,10);if(!*s||*s=='-'||*e||errno)stop("number",s);return n;}
static uint64_t pin(const char *s,size_t n)
{uint64_t h=UINT64_C(14695981039346656037);size_t i;for(i=0;i<n;++i){h^=(unsigned char)s[i];h*=UINT64_C(1099511628211);}return h;}
static int hex(char c)
{if(c>='0'&&c<='9')return c-'0';if(c>='A'&&c<='F')return c-'A'+10;if(c>='a'&&c<='f')return c-'a'+10;return -1;}
static void decode(char *s)
{char *o=s;while(*s){if(*s=='%'){int a,b;if(!s[1]||!s[2]||(a=hex(s[1]))<0||(b=hex(s[2]))<0||!(a*16+b))stop("escape",s);*o++=(char)(a*16+b);s+=3;}else *o++=*s++;}*o=0;}
static void xmln(FILE *out,const char *s,size_t n)
{size_t i;for(i=0;i<n;++i)switch(s[i]){case '&':fputs("&amp;",out);break;case '<':fputs("&lt;",out);break;case '>':fputs("&gt;",out);break;case '"':fputs("&quot;",out);break;case '\r':fputs("&#13;",out);break;default:fputc((unsigned char)s[i],out);}}
static void xml(FILE *out,const char *s){xmln(out,s,strlen(s));}
/* XML 1.0 cannot represent arbitrary C file bytes. Hex only those fields that
 * need it, explicitly marked, while retaining readable UTF-8 everywhere else. */
static int utf8_unit(const unsigned char *s,size_t n)
{
    unsigned long cp;int k,i;if(!n)return 0;
    if(s[0]<128)return (s[0]>=32||s[0]==9||s[0]==10||s[0]==13)?1:0;
    if(s[0]>=0xc2&&s[0]<=0xdf){k=2;cp=s[0]&31u;}
    else if(s[0]>=0xe0&&s[0]<=0xef){k=3;cp=s[0]&15u;}
    else if(s[0]>=0xf0&&s[0]<=0xf4){k=4;cp=s[0]&7u;}
    else return 0;
    if(n<(size_t)k)return 0;
    for(i=1;i<k;++i){if((s[i]&0xc0)!=0x80)return 0;cp=(cp<<6)|(s[i]&63u);}
    if((k==3&&cp<0x800)||(k==4&&cp<0x10000)||(cp>=0xd800&&cp<=0xdfff)||cp>0x10ffff||cp==0xfffe||cp==0xffff)return 0;
    return k;
}
static int xml_safe(const char *s,size_t n)
{size_t p=0;while(p<n){int k=utf8_unit((const unsigned char *)s+p,n-p);if(!k)return 0;p+=(size_t)k;}return 1;}
static void value_start(FILE *o,const char *s,size_t n)
{fputs(xml_safe(s,n)?">":" encoding=\"hex-bytes\">",o);}
static void value_text(FILE *o,const char *s,size_t n)
{size_t i;if(xml_safe(s,n))xmln(o,s,n);else for(i=0;i<n;++i)fprintf(o,"%02X",(unsigned char)s[i]);}
static void span_tag(FILE *o,const char *name,const char *s,size_t n)
{fprintf(o,"<%s",name);value_start(o,s,n);value_text(o,s,n);fprintf(o,"</%s>\n",name);}
static void tag(FILE *out,const char *name,const char *value)
{span_tag(out,name,value,strlen(value));}
static int find_function(Data *d,const char *id)
{int i;for(i=0;i<d->nf;++i)if(!strcmp(d->f[i].id,id))return i;return -1;}
static int find_source(Data *d,const char *path)
{int i;for(i=0;i<d->ns;++i)if(!strcmp(d->s[i].path,path))return i;return -1;}
static Source *source(Data *d,Function *f)
{int i=find_source(d,f->file);if(i<0)stop("missing_source_bytes",f->file);return &d->s[i];}
static void fields(Record *r,int n){if(r->n!=n)stop("record_field_count",r->v[0]);}
static int section_of(Function *f)
{return f->home&&f->home[0]>='A'&&f->home[0]<='O'&&f->home[1]>='a'&&f->home[1]<='z'&&f->home[2]=='-'?f->home[0]-'A':-1;}
static size_t line_at(Source *s,size_t off)
{size_t i,n=1;if(off>s->length)stop("source_location",s->path);for(i=0;i<off;++i)if(s->bytes[i]=='\n')++n;return n;}
static void load(Data *d,const char *path)
{
    FILE *in=fopen(path,"rb");char *p,*end;int i,last=-1;
    if(!in)stop("read",path);
    d->length=fread(d->arena,1,ARENA-1,in);
    if(ferror(in)||fgetc(in)!=EOF)stop("registry_capacity_or_read",path);
    if(fclose(in))stop("close",path);
    if(memchr(d->arena,0,d->length))stop("nul",path);
    d->arena[d->length]=0;p=d->arena;
    while(*p){Record *r;char *q;int k;
        end=strchr(p,'\n');if(!end)stop("record_requires_newline",path);*end=0;
        if(d->nr==RECORDS)stop("record_capacity",path);
        r=&d->r[d->nr++];
        r->v[r->n++]=p;for(q=p;*q;++q)if(*q=='|'){*q=0;if(r->n==FIELDS)stop("fields_capacity",p);r->v[r->n++]=q+1;}
        for(k=1;k<r->n;++k)decode(r->v[k]);
        if(!strcmp(p,"FORMAT")){fields(r,3);if(strcmp(r->v[1],"shakti_source_walk")||strcmp(r->v[2],"1"))stop("walk_format",path);}
        else if(!strcmp(p,"SOURCE")){fields(r,2);d->revision=r->v[1];}
        else if(!strcmp(p,"SECTION_KEY")){fields(r,3);if(strlen(r->v[1])!=1||r->v[1][0]<'A'||r->v[1][0]>'O')stop("section_key",r->v[1]);d->section[r->v[1][0]-'A']=r->v[2];}
        else if(!strcmp(p,"SUBSECTION_KEY")){fields(r,3);if(strlen(r->v[1])!=2||r->v[1][0]<'A'||r->v[1][0]>'O'||r->v[1][1]<'a'||r->v[1][1]>'z')stop("subsection_key",r->v[1]);d->sub[r->v[1][0]-'A'][r->v[1][1]-'a']=r->v[2];}
        else if(!strcmp(p,"FILE")){Source *s;fields(r,5);if(d->ns==FILES||find_source(d,r->v[1])>=0)stop("source_capacity_or_duplicate",r->v[1]);s=&d->s[d->ns++];s->path=r->v[1];s->length=number(r->v[2]);s->pin=r->v[3];}
        else if(!strcmp(p,"BYTES")){int s;fields(r,3);s=find_source(d,r->v[1]);if(s<0||d->s[s].bytes)stop("bytes_owner",r->v[1]);d->s[s].bytes=r->v[2];}
        else if(!strcmp(p,"FN")){Function *f;fields(r,8);if(d->nf==FUNCS)stop("function_capacity",path);if(last>=0)d->f[last].last=d->nr-1;last=d->nf++;f=&d->f[last];f->file=r->v[1];f->name=r->v[2];f->type=r->v[3];f->decl=r->v[4];f->start=number(r->v[5]);f->end=number(r->v[6]);f->first=d->nr-1;f->at=-1;f->depth=-1;
            if(snprintf(f->id,sizeof(f->id),"%s#%s",f->file,f->name)>=(int)sizeof(f->id))stop("identity_capacity",f->name);
            for(i=0;i<last;++i)if(!strcmp(d->f[i].id,f->id))stop("duplicate_identity",f->id);
        }else if(!strcmp(p,"AT")){Function *f;fields(r,6);i=find_function(d,r->v[1]);if(i<0||d->f[i].at>=0)stop("AT_identity",r->v[1]);f=&d->f[i];f->at=d->nr-1;f->home=r->v[5];f->depth=!strcmp(r->v[3],"-1")?-1:(int)number(r->v[3]);}
        p=end+1;
    }
    if(last>=0)d->f[last].last=d->nr;
    if(!d->nr||strcmp(d->r[0].v[0],"FORMAT")||!d->revision||!d->nf)stop("incomplete_registry",path);
    for(i=0;i<d->ns;++i){Source *s=&d->s[i];char h[32];if(!s->bytes||strlen(s->bytes)!=s->length)stop("source_length",s->path);snprintf(h,sizeof(h),"%016" PRIX64,pin(s->bytes,s->length));if(strcmp(h,s->pin))stop("source_pin",s->path);}
    for(i=0;i<d->nf;++i){Function *f=&d->f[i];Source *s=source(d,f);char h[32];int j,outs=0,ins=0;
        if(f->at<0||f->start>=f->end||f->end>s->length||s->bytes[f->end-1]!='}')stop("function_span_or_closing_brace",f->id);
        snprintf(h,sizeof(h),"%016" PRIX64,pin(s->bytes+f->start,f->end-f->start));if(strcmp(h,d->r[f->at].v[4]))stop("function_pin",f->id);
        if(strcmp(f->home,"OPEN")&&section_of(f)<0)stop("issued_home",f->home);
        for(j=0;j<i;++j)if(strcmp(f->home,"OPEN")&&!strcmp(f->home,d->f[j].home))stop("duplicate_home",f->home);
        for(j=f->first+1;j<f->last;++j){Record *r=&d->r[j];char *kind=r->v[0];
            if(!strcmp(kind,"IN")){fields(r,8);if(strcmp(r->v[1],f->id)||number(r->v[2])!=(unsigned long)++ins||number(r->v[6])<f->start||number(r->v[7])>f->end||number(r->v[6])>=number(r->v[7]))stop("input_identity_or_span",f->id);}
            else if(!strcmp(kind,"OUT")){fields(r,5);if(strcmp(r->v[1],f->id)||strcmp(r->v[2],"return")||strcmp(r->v[3],f->type))stop("return_channel",f->id);++outs;}
            else if(!strcmp(kind,"EFFECT")||!strcmp(kind,"CALL")){size_t a,b;fields(r,7);a=number(r->v[2]);b=number(r->v[3]);if(strcmp(r->v[1],f->id)||a<f->start||b>f->end||a>=b)stop("effect_or_call_span",f->id);if(!strcmp(kind,"EFFECT")&&!strcmp(r->v[4],"return_site")&&(b-a<7||strncmp(s->bytes+a,"return",6)||s->bytes[b-1]!=';'))stop("return_statement_span",f->id);}
            else if(!strcmp(kind,"ARG"))fields(r,6);
            else if(!strcmp(kind,"BIND"))fields(r,9);
        }
        if(outs!=1)stop("missing_return_channel",f->id);
    }
    for(i=0;i<d->nr;++i){Record *r=&d->r[i];
        if(!strcmp(r->v[0],"CALL")&&r->v[4][0]!='?'&&find_function(d,r->v[4])<0)stop("unresolved_declared_direct_call",r->v[4]);
        if(!strcmp(r->v[0],"BIND")){
            int a=find_function(d,r->v[1]),b=find_function(d,r->v[3]),c=find_function(d,r->v[5]),j,parameter=0,argument=0;
            Record *outer=NULL,*inner=NULL;Function *caller,*receiver;
            if(a<0||b<0||c<0||strcmp(r->v[2],"return"))stop("binding_identity",r->v[1]);
            caller=&d->f[c];receiver=&d->f[b];
            for(j=caller->first+1;j<caller->last;++j){Record *q=&d->r[j];
                if(!strcmp(q->v[0],"CALL")&&!strcmp(q->v[2],r->v[6])&&!strcmp(q->v[4],r->v[3]))outer=q;
                if(!strcmp(q->v[0],"CALL")&&!strcmp(q->v[2],r->v[7])&&!strcmp(q->v[4],r->v[1]))inner=q;
                if(!strcmp(q->v[0],"ARG")&&!strcmp(q->v[2],r->v[6])&&!strcmp(q->v[3],r->v[4])&&!strcmp(q->v[5],d->f[a].type))argument=1;
            }
            for(j=receiver->first+1;j<receiver->last;++j){Record *q=&d->r[j];if(!strcmp(q->v[0],"IN")&&!strcmp(q->v[2],r->v[4])&&!strcmp(q->v[4],d->f[a].type))parameter=1;}
            if(!outer||!inner||!parameter||!argument||number(inner->v[2])<=number(outer->v[2])||number(inner->v[3])>=number(outer->v[3]))stop("binding_call_or_parameter_evidence",r->v[1]);
        }
    }
}
static int selected(Function *f,const char *scope)
{if(!strcmp(scope,"MASTER"))return 1;if(!strcmp(scope,"OPEN"))return section_of(f)<0;return section_of(f)>=0&&!strncmp(f->home,scope,strlen(scope));}
static int count_records(Data *d,Function *f,const char *kind,const char *effect)
{int j,n=0;for(j=f->first+1;j<f->last;++j){Record *r=&d->r[j];if(!strcmp(r->v[0],kind)&&(!effect||!strcmp(r->v[4],effect)))++n;}return n;}
static int source_order(Data *d,Function *f)
{int i,n=1;for(i=0;i<d->nf;++i)if(!strcmp(d->f[i].file,f->file)&&d->f[i].start<f->start)++n;return n;}
static void incoming_xml(FILE *o,Data *d,Function *f)
{
    int i,j,k,count=0;
    fputs("<incoming_calls>\n",o);
    for(i=0;i<d->nr;++i){Record *r=&d->r[i];int ci;Function *caller;Source *s;
        if(strcmp(r->v[0],"CALL")||strcmp(r->v[4],f->id))continue;
        ci=find_function(d,r->v[1]);if(ci<0)stop("incoming_caller",r->v[1]);caller=&d->f[ci];s=source(d,caller);++count;
        fputs("<call caller_identity=\"",o);xml(o,caller->id);fputs("\" caller_address=\"",o);xml(o,caller->home);
        fprintf(o,"\" start_byte=\"%s\" end_byte_exclusive=\"%s\" line=\"%lu\">\n",r->v[2],r->v[3],(unsigned long)line_at(s,number(r->v[2])));
        tag(o,"caller_name",caller->name);tag(o,"caller_filename",caller->file);
        span_tag(o,"call_expression",s->bytes+number(r->v[2]),number(r->v[3])-number(r->v[2]));
        for(j=caller->first+1;j<caller->last;++j){Record *a=&d->r[j];int bound=0;
            if(strcmp(a->v[0],"ARG")||strcmp(a->v[2],r->v[2]))continue;
            fprintf(o,"<supplied_input ordinal=\"%s\">\n",a->v[3]);tag(o,"argument_expression",a->v[4]);tag(o,"declared_input_type",a->v[5]);
            for(k=f->first+1;k<f->last;++k){Record *p=&d->r[k];if(!strcmp(p->v[0],"IN")&&!strcmp(p->v[2],a->v[3]))tag(o,"parameter_name",p->v[3]);}
            for(k=caller->first+1;k<caller->last;++k){Record *b=&d->r[k];
                if(!strcmp(b->v[0],"BIND")&&!strcmp(b->v[3],f->id)&&!strcmp(b->v[4],a->v[3])&&!strcmp(b->v[5],caller->id)&&!strcmp(b->v[6],r->v[2])){
                    int pi=find_function(d,b->v[1]);if(pi<0)stop("producer_identity",b->v[1]);
                    fputs("<producer_return state=\"PROVEN_NESTED_CALL\" identity=\"",o);xml(o,b->v[1]);fputs("\" address=\"",o);xml(o,d->f[pi].home);fprintf(o,"\" call_byte=\"%s\">",b->v[7]);xml(o,d->f[pi].name);fputs("</producer_return>\n",o);bound=1;
                }
            }
            if(!bound)fputs("<producer_return state=\"NOT_ESTABLISHED_BY_COLLECTOR\"/>\n",o);
            fputs("</supplied_input>\n",o);
        }
        fputs("</call>\n",o);
    }
    fprintf(o,"<count>%d</count>\n</incoming_calls>\n",count);
}
static void function_xml(FILE *o,Data *d,Function *f)
{
    Source *s=source(d,f);int j;
    fputs("<function identity=\"",o);xml(o,f->id);fputs("\" address=\"",o);xml(o,f->home);fputs("\">\n",o);
    tag(o,"filename",f->file);tag(o,"name",f->name);tag(o,"declared_return_type",f->type);tag(o,"declaration",f->decl);
    fprintf(o,"<function_order source_file_ordinal=\"%d\" registry_ordinal=\"%ld\" walk_order=\"",source_order(d,f),(long)(f-d->f)+1);xml(o,d->r[f->at].v[2]);fputs("\"/>\n",o);
    fprintf(o,"<location start_byte=\"%lu\" end_byte_exclusive=\"%lu\" closing_brace_byte=\"%lu\" start_line=\"%lu\" closing_brace_line=\"%lu\"/>\n",(unsigned long)f->start,(unsigned long)f->end,(unsigned long)(f->end-1),(unsigned long)line_at(s,f->start),(unsigned long)line_at(s,f->end-1));
    fprintf(o,"<walk_depth>%d</walk_depth>\n<inputs>\n",f->depth);
    for(j=f->first+1;j<f->last;++j){Record *r=&d->r[j];if(!strcmp(r->v[0],"IN")){fprintf(o,"<input ordinal=\"%s\" start_byte=\"%s\" end_byte_exclusive=\"%s\">\n",r->v[2],r->v[6],r->v[7]);tag(o,"name",r->v[3]);tag(o,"type",r->v[4]);span_tag(o,"source_declaration",s->bytes+number(r->v[6]),number(r->v[7])-number(r->v[6]));fputs("</input>\n",o);}}
    fputs("</inputs>\n<outputs>\n<return_channel>",o);xml(o,f->type);fputs("</return_channel>\n",o);
    for(j=f->first+1;j<f->last;++j){Record *r=&d->r[j];if(!strcmp(r->v[0],"EFFECT")){size_t a=number(r->v[2]),b=number(r->v[3]);fprintf(o,"<effect kind=\"%s\" start_byte=\"%lu\" end_byte_exclusive=\"%lu\" line=\"%lu\"",r->v[4],(unsigned long)a,(unsigned long)b,(unsigned long)line_at(s,a));value_start(o,s->bytes+a,b-a);value_text(o,s->bytes+a,b-a);fputs("</effect>\n",o);}}
    fputs("</outputs>\n<relationships>\n",o);
    for(j=f->first+1;j<f->last;++j){Record *r=&d->r[j];int k;if(strcmp(r->v[0],"CALL")&&strcmp(r->v[0],"ARG")&&strcmp(r->v[0],"BIND"))continue;fprintf(o,"<record kind=\"%s\">",r->v[0]);for(k=1;k<r->n;++k){fprintf(o,"<field ordinal=\"%d\"",k);value_start(o,r->v[k],strlen(r->v[k]));value_text(o,r->v[k],strlen(r->v[k]));fputs("</field>",o);}fputs("</record>\n",o);}
    fputs("</relationships>\n",o);incoming_xml(o,d,f);span_tag(o,"source_function",s->bytes+f->start,f->end-f->start);fputs("<review_state>OPEN</review_state>\n</function>\n",o);
}
static FILE *newfile(const char *relative)
{char path[PATH];FILE *o,*p;if(snprintf(path,sizeof(path),"%s/%s",output_path,relative)>=(int)sizeof(path))stop("path_capacity",relative);p=fopen(path,"rb");if(p){fclose(p);stop("output_exists",path);}o=fopen(path,"wb");if(!o)stop("write",path);return o;}
static void closeout(FILE *o){int bad=ferror(o);if(fclose(o))bad=1;if(bad)stop("write_or_close",output_path);}
static void directory(const char *relative)
{char p[PATH];if(snprintf(p,sizeof(p),"%s/%s",output_path,relative)>=(int)sizeof(p))stop("path_capacity",relative);if(mkdir(p,0700))stop("mkdir",p);}
static const char *section_name(Data *d,int s)
{return d->section[s]?d->section[s]:"PHYSICAL HOME - logical role unassigned";}
static int source_section(Data *d,Source *s)
{int i,home=-1;for(i=0;i<d->nf;++i)if(!strcmp(d->f[i].file,s->path)){int h=section_of(&d->f[i]);if(home>=0&&h!=home)stop("source_multiple_sections",s->path);home=h;}return home;}
static void section_path(char *out,size_t cap,int s)
{if(s<0)copy(out,cap,"UNASSIGNED-SOURCE");else if(snprintf(out,cap,"SECTION\xE2\x80\x94%c",'A'+s)>=(int)cap)stop("section_path_capacity","");}
static void source_destination(Data *d,Source *s,char *out,size_t cap)
{char dir[64];const char *base=strrchr(s->path,'/');base=base?base+1:s->path;section_path(dir,sizeof(dir),source_section(d,s));if(!*base||snprintf(out,cap,"%s/%s",dir,base)>=(int)cap)stop("source_filename",s->path);}
static void write_xml(const char *relative,const char *scope)
{
    FILE *o=newfile(relative);int i,k;
    fputs("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<master_walk version=\"1\" scope=\"",o);xml(o,scope);fputs("\" source_revision=\"",o);xml(o,now.revision);fputs("\" evidence=\"source_walk_registry\">\n<definitions>Byte offsets are zero-based; ends are exclusive. Lines are one-based. CALL is control/call evidence. BIND is a source-proven nested-return-to-argument binding. Review remains OPEN. Logical roles and physical homes are separate.</definitions>\n<ownership>\n",o);
    for(i=0;i<15;++i)if(!strcmp(scope,"MASTER")||scope[0]=='A'+i){fprintf(o,"<section id=\"%c\"><role>",'A'+i);xml(o,section_name(&now,i));fputs("</role>\n",o);for(k=0;k<26;++k)if(now.sub[i][k]){fprintf(o,"<logical_subsection id=\"%c%c\">",'A'+i,'a'+k);xml(o,now.sub[i][k]);fputs("</logical_subsection>\n",o);}fputs("</section>\n",o);}
    fputs("</ownership>\n<source_files>\n",o);
    for(i=0;i<now.ns;++i){Source *s=&now.s[i];int h=source_section(&now,s);char dest[PATH];
        if(strcmp(scope,"MASTER")&&((!strcmp(scope,"OPEN")&&h>=0)||(strcmp(scope,"OPEN")&&(h<0||scope[0]!='A'+h))))continue;
        source_destination(&now,s,dest,sizeof(dest));fputs("<file original_path=\"",o);xml(o,s->path);fputs("\" cabinet_path=\"",o);xml(o,dest);fprintf(o,"\" bytes=\"%lu\" fnv1a64=\"%s\" home_state=\"%s\"/>\n",(unsigned long)s->length,s->pin,h>=0?"ISSUED_FUNCTION_HOME":"UNASSIGNED");
    }
    fputs("</source_files>\n",o);
    tag(o,"source_field_encoding","Readable escaped UTF-8 unless encoding=hex-bytes is present. For hex-bytes decode each hex pair to the original byte; XML 1.0 cannot directly represent those bytes. SVG displays control/invalid bytes as backslash-xHH.");
    fputs("<functions>\n",o);for(i=0;i<now.nf;++i)if(selected(&now.f[i],scope))function_xml(o,&now,&now.f[i]);
    fputs("</functions>\n<retained_evidence>\n",o);
    for(i=0;i<now.nr;++i){Record *r=&now.r[i];if(strcmp(r->v[0],"RESERVED")&&strcmp(r->v[0],"SOURCE_GAP")&&strcmp(r->v[0],"DECL_CHANGE")&&strcmp(r->v[0],"SEE_KEY")&&strcmp(r->v[0],"BLOB"))continue;fprintf(o,"<record kind=\"%s\">",r->v[0]);for(k=1;k<r->n;++k){fprintf(o,"<field ordinal=\"%d\">",k);xml(o,r->v[k]);fputs("</field>",o);}fputs("</record>\n",o);}
    fputs("</retained_evidence>\n</master_walk>\n",o);closeout(o);
}
/* Canonical exact evidence comparison; no hash-only equality decisions. */
static int equal_function(Function *a,Function *b)
{
    FILE *x=tmpfile(),*y=tmpfile();int cx,cy,equal=1;if(!x||!y)stop("temporary_compare",a->id);
    function_xml(x,&now,a);function_xml(y,&before,b);if(fflush(x)||fflush(y))stop("compare_flush",a->id);rewind(x);rewind(y);
    do{cx=fgetc(x);cy=fgetc(y);if(cx!=cy){equal=0;break;}}while(cx!=EOF);
    if(ferror(x)||ferror(y))stop("compare_read",a->id);
    fclose(x);fclose(y);return equal;
}
static void differences(void)
{
    FILE *o=newfile("diff.xml");int i,added=0,changed=0,removed=0;
    fprintf(o,"<diff state=\"%s\">\n",have_prior?"COMPARED":"BASELINE_ONLY");
    tag(o,"current_revision",now.revision);
    if(have_prior)tag(o,"previous_revision",before.revision);
    if(have_prior){
        for(i=0;i<now.ns;++i){Source *s=&now.s[i];int j=find_source(&before,s->path);const char *kind;
            if(j<0)kind="ADDED";else if(s->length!=before.s[j].length||memcmp(s->bytes,before.s[j].bytes,s->length))kind="CHANGED";else continue;
            fprintf(o,"<source_file state=\"%s\" path=\"",kind);xml(o,s->path);fputs("\"/>\n",o);
        }
        for(i=0;i<before.ns;++i)if(find_source(&now,before.s[i].path)<0){fputs("<source_file state=\"ABSENT_CURRENT\" path=\"",o);xml(o,before.s[i].path);fputs("\"/>\n",o);}
    }
    if(have_prior){for(i=0;i<now.nf;++i){int j=find_function(&before,now.f[i].id);const char *kind;if(j<0){kind="ADDED";++added;}else if(!equal_function(&now.f[i],&before.f[j])){kind="CHANGED";++changed;}else continue;fprintf(o,"<function state=\"%s\" identity=\"",kind);xml(o,now.f[i].id);fputs("\" address=\"",o);xml(o,now.f[i].home);fputs("\"/>\n",o);}
        for(i=0;i<before.nf;++i)if(find_function(&now,before.f[i].id)<0){fputs("<function state=\"ABSENT_CURRENT\" identity=\"",o);xml(o,before.f[i].id);fputs("\" prior_address=\"",o);xml(o,before.f[i].home);fputs("\"/>\n",o);++removed;}}
    fprintf(o,"<counts added=\"%d\" changed=\"%d\" absent_current=\"%d\"/>\n</diff>\n",added,changed,removed);closeout(o);
}

/* Diagram emitter shares the parsed facts with all XML views. */
#include "scopewalk_draw.h"
#include "scopewalk_flat.h"

static void config(const char *path)
{FILE *f=fopen(path,"rb");char line[8192];int seen=0;if(!f)stop("config",path);while(fgets(line,sizeof(line),f)){char *p;size_t n=strlen(line);if(n==sizeof(line)-1)stop("config_capacity",path);while(n&&(line[n-1]=='\n'||line[n-1]=='\r'))line[--n]=0;if(!n||line[0]=='#')continue;p=strchr(line,'=');if(!p)stop("config_key_value",line);*p++=0;if(!strcmp(line,"input_registry")){copy(input_path,sizeof(input_path),p);seen|=1;}else if(!strcmp(line,"previous_registry"))copy(prior_path,sizeof(prior_path),p);else if(!strcmp(line,"output_dir")){copy(output_path,sizeof(output_path),p);seen|=2;}else if(!strcmp(line,"render"))copy(render_list,sizeof(render_list),p);else stop("unknown_config_key",line);}if(ferror(f)||fclose(f))stop("config_read",path);if(seen!=3)stop("required_config",path);}
static void preserve_registry(void)
{FILE *in=fopen(input_path,"rb"),*out=newfile("walk_registry.txt");char buf[8192];size_t n;if(!in)stop("registry_copy",input_path);while((n=fread(buf,1,sizeof(buf),in))!=0)if(fwrite(buf,1,n,out)!=n)stop("registry_copy_write",input_path);if(ferror(in)||fclose(in))stop("registry_copy_read",input_path);closeout(out);}
int main(int argc,char **argv)
{
    int s,k,i;char path[PATH],scope[16],dir[64],*p,*next;int all=0;
    if(argc!=2){fputs("usage: scopewalk views.conf\n",stderr);return 2;}
    config(argv[1]);load(&now,input_path);if(prior_path[0]){load(&before,prior_path);have_prior=1;}
    if(mkdir(output_path,0700))stop("fresh_output_directory_required",output_path);
    preserve_registry();write_xml("master_walk.xml","MASTER");differences();
    for(s=0;s<15;++s){scope[0]=(char)('A'+s);scope[1]=0;section_path(dir,sizeof(dir),s);directory(dir);snprintf(path,sizeof(path),"%s/function.xml",dir);write_xml(path,scope);section_text(dir,scope);
    }
    directory("UNASSIGNED-SOURCE");write_xml("UNASSIGNED-SOURCE/function.xml","OPEN");section_text("UNASSIGNED-SOURCE","OPEN");export_sources();
    p=render_list;while(*p){next=strchr(p,',');if(next)*next=0;
        if(!strcmp(p,"ALL")){all=2;if(!next)break;p=next+1;continue;}
        if(!strcmp(p,"SECTIONS")){if(!all)all=1;if(!next)break;p=next+1;continue;}
        if(strcmp(p,"MASTER")&&(strlen(p)<1||strlen(p)>2||p[0]<'A'||p[0]>'O'||(p[1]&&(p[1]<'a'||p[1]>'z'))))stop("render_scope",p);
        if(!strcmp(p,"MASTER"))copy(path,sizeof(path),"master_walk.svg");else {section_path(dir,sizeof(dir),p[0]-'A');if(strlen(p)==1)snprintf(path,sizeof(path),"%s/section.svg",dir);else snprintf(path,sizeof(path),"%s/%c%c.svg",dir,p[0],p[1]);}
        draw_view(path,p);if(!next)break;p=next+1;
    }
    if(all)for(s=0;s<15;++s){section_path(dir,sizeof(dir),s);scope[0]=(char)('A'+s);scope[1]=0;snprintf(path,sizeof(path),"%s/section.svg",dir);draw_view(path,scope);
        if(all==2)for(k=0;k<26;++k){int exists=now.sub[s][k]!=NULL;for(i=0;i<now.nf;++i)if(section_of(&now.f[i])==s&&now.f[i].home[1]=='a'+k)exists=1;if(exists){scope[1]=(char)('a'+k);scope[2]=0;snprintf(path,sizeof(path),"%s/%s.svg",dir,scope);draw_view(path,scope);}}
    }
    write_findings();
    {FILE *o=newfile("BUILD_COMPLETE.txt");fprintf(o,"SOURCE_REVISION=%s\nFUNCTIONS=%d\nSOURCE_FILES=%d\nDIRECTORIES=SECTION-A through SECTION-O (em dash); UNASSIGNED-SOURCE\nSECTION_XML=function.xml (one per flat folder)\nREVIEW_STATE=OPEN\nINPUT=walk_registry.txt\nMASTER=master_walk.xml\nDIFF=diff.xml\nSOURCE_MAP=source_map.tsv\n",now.revision,now.nf,now.ns);closeout(o);}
    printf("PASS|scopewalk|files=%d|functions=%d|output=%s\n",now.ns,now.nf,output_path);return 0;
}
