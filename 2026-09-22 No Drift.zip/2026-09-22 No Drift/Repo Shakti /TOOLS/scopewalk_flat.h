/* Flat source cabinet. Preserve each admitted source file byte for byte. */
static void section_text(const char *dir,const char *scope)
{
    char path[PATH];FILE *o;int i,j,k,count=0;
    if(snprintf(path,sizeof(path),"%s/section.txt",dir)>=(int)sizeof(path))stop("text_path",dir);
    o=newfile(path);fprintf(o,"SECTION %s\nSOURCE REVISION: %s\n",scope,now.revision);
    fputs("COVERAGE: full supplied registry; source review OPEN.\nORDER: source file ordinal is one-based; walk order is the collector's zero-based traversal.\nLOCATIONS: byte offsets zero-based, end exclusive; lines one-based.\nCALL identifies the caller; BIND identifies a proven producer return supplied to an input.\n\n",o);
    for(i=0;i<now.nf;++i)if(selected(&now.f[i],scope)){Function *f=&now.f[i];Source *s=source(&now,f);int n=0;++count;
        fprintf(o,"FUNCTION: %s | %s\nFILE: %s\nSOURCE FILE ORDER: %d\nWALK ORDER: %s\nDECLARATION: %s\nRETURN TYPE: %s\nCLOSING BRACE: byte %lu; line %lu\nINPUTS:\n",f->home,f->name,f->file,source_order(&now,f),now.r[f->at].v[2],f->decl,f->type,(unsigned long)(f->end-1),(unsigned long)line_at(s,f->end-1));
        for(j=f->first+1;j<f->last;++j){Record *r=&now.r[j];if(!strcmp(r->v[0],"IN")){size_t a=number(r->v[6]),b=number(r->v[7]);fprintf(o,"i%s | %s | %s | bytes %lu:%lu\n",r->v[2],r->v[3],r->v[4],(unsigned long)a,(unsigned long)b);fwrite(s->bytes+a,1,b-a,o);fputc('\n',o);++n;}}
        if(!n)fputs("none declared\n",o);
        fputs("RETURN STATEMENTS:\n",o);n=0;
        for(j=f->first+1;j<f->last;++j){Record *r=&now.r[j];if(!strcmp(r->v[0],"EFFECT")&&!strcmp(r->v[4],"return_site")){size_t a=number(r->v[2]),b=number(r->v[3]);fprintf(o,"line %lu | bytes %lu:%lu\n",(unsigned long)line_at(s,a),(unsigned long)a,(unsigned long)b);fwrite(s->bytes+a,1,b-a,o);fputc('\n',o);++n;}}
        if(!n)fputs("none explicitly collected\n",o);
        fputs("INCOMING CALLS / SUPPLIED INPUTS:\n",o);n=0;
        for(j=0;j<now.nr;++j){Record *r=&now.r[j];int ci;Function *caller;
            if(strcmp(r->v[0],"CALL")||strcmp(r->v[4],f->id))continue;
            ci=find_function(&now,r->v[1]);caller=&now.f[ci];++n;
            fprintf(o,"FROM %s | %s | %s | byte %s\n",caller->name,caller->home,caller->file,r->v[2]);
            for(k=caller->first+1;k<caller->last;++k){Record *a=&now.r[k];if(!strcmp(a->v[0],"ARG")&&!strcmp(a->v[2],r->v[2]))fprintf(o,"i%s <= %s\n",a->v[3],a->v[4]);}
        }
        if(!n)fputs("No resolved direct caller in this registry; review remains OPEN.\n",o);
        fputs("PROVEN RETURN-TO-INPUT BINDINGS:\n",o);n=0;
        for(j=0;j<now.nr;++j){Record *b=&now.r[j];if(!strcmp(b->v[0],"BIND")&&!strcmp(b->v[3],f->id)){fprintf(o,"%s return -> i%s | caller %s | outer byte %s | producer byte %s\n",b->v[1],b->v[4],b->v[5],b->v[6],b->v[7]);++n;}}
        if(!n)fputs("No producer-return binding established by this collector.\n",o);
        fputs("\n",o);
    }
    fprintf(o,"FUNCTION COUNT: %d\n",count);closeout(o);
}
static void export_sources(void)
{
    int i,j;FILE *map=newfile("source_map.tsv");char destinations[FILES][PATH];
    fputs("original_path\tcabinet_path\tbytes\tfnv1a64\thome_state\n",map);
    for(i=0;i<now.ns;++i){Source *s=&now.s[i];FILE *o;
        source_destination(&now,s,destinations[i],sizeof(destinations[i]));
        for(j=0;j<i;++j)if(!strcmp(destinations[i],destinations[j]))stop("flat_filename_collision",s->path);
        o=newfile(destinations[i]);if(fwrite(s->bytes,1,s->length,o)!=s->length)stop("source_copy",s->path);closeout(o);
        fprintf(map,"%s\t%s\t%lu\t%s\t%s\n",s->path,destinations[i],(unsigned long)s->length,s->pin,source_section(&now,s)>=0?"ISSUED_FUNCTION_HOME":"UNASSIGNED");
    }
    closeout(map);
}
