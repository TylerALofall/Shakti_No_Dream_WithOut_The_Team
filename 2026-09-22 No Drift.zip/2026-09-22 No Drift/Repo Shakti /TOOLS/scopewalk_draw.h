/* Static, two-pass measured SVG views. Included by scopewalk.c. */
typedef struct { char key[PATH]; int fi,x,y,w,h; } ViewNode;
typedef struct { int a,b,target,calls,binds,direct; const char *unknown,*reason; } ViewEdge;
static ViewNode vn[NODES];
static ViewEdge ve[EDGES];
static int nn,ne;
static int natural_width;
static const char *node_color(int i)
{
    int e;const char *key=vn[i].key;
    if(!strncmp(key,"Ag",2))return "#b52f70";
    if(key[0]=='G')return "#2563eb";
    for(e=0;e<ne;++e)if((ve[e].a==i&&ve[e].target>=0&&section_of(&now.f[ve[e].target])==0)||(ve[e].b==i&&vn[ve[e].a].key[0]=='A'))return "#c25c14";
    if(key[0]=='F')return "#7c3eb2";
    if(key[0]=='I')return "#987200";
    if(key[0]=='B')return "#208653";
    return "#516782";
}
static int node_for(Function *f,const char *scope)
{
    int i;
    if(!selected(f,scope))return -1;
    for(i=0;i<nn;++i){
        if(vn[i].fi>=0){if(&now.f[vn[i].fi]==f)return i;}
        else if(selected(f,vn[i].key))return i;
    }
    return -1;
}
static void add_node(const char *key,int fi)
{
    if(nn==NODES)stop("view_node_capacity",key);
    copy(vn[nn].key,sizeof(vn[nn].key),key);vn[nn].fi=fi;++nn;
}
static void add_edge(int a,int b,int target,const char *unknown,int bind)
{
    int i;ViewEdge *e;
    for(i=0;i<ne;++i)if(ve[i].a==a&&ve[i].b==b&&
        (b>=0||(ve[i].target==target&&!strcmp(ve[i].unknown,unknown))))break;
    if(i==ne){if(ne==EDGES)stop("view_edge_capacity","");e=&ve[ne++];memset(e,0,sizeof(*e));e->a=a;e->b=b;e->target=target;e->unknown=unknown;e->reason="unaligned centers";}
    e=&ve[i];if(bind)++e->binds;else ++e->calls;
}
static void view_model(const char *scope)
{
    int i;char key[8];nn=ne=0;
    if(!strcmp(scope,"MASTER")){
        for(i=0;i<15;++i){key[0]=(char)('A'+i);key[1]=0;add_node(key,-1);}
        for(i=0;i<now.nf;++i)if(section_of(&now.f[i])<0){add_node("OPEN",-1);break;}
    }else if(strlen(scope)==1){int k;
        for(k=0;k<26;++k){int use=now.sub[scope[0]-'A'][k]!=NULL;
            for(i=0;i<now.nf;++i)if(selected(&now.f[i],scope)&&now.f[i].home[1]=='a'+k)use=1;
            if(use){key[0]=scope[0];key[1]=(char)('a'+k);key[2]=0;add_node(key,-1);}
        }
    }else for(i=0;i<now.nf;++i)if(selected(&now.f[i],scope))add_node(now.f[i].home,i);
    for(i=0;i<now.nr;++i){Record *r=&now.r[i];int a,b,from,to,bind=0;const char *target;
        if(!strcmp(r->v[0],"CALL")){from=find_function(&now,r->v[1]);target=r->v[4];}
        else if(!strcmp(r->v[0],"BIND")){from=find_function(&now,r->v[1]);target=r->v[3];bind=1;}
        else continue;
        if(from<0||(a=node_for(&now.f[from],scope))<0)continue;
        to=find_function(&now,target);b=to>=0?node_for(&now.f[to],scope):-1;
        if(a==b&&vn[a].fi<0)continue; /* internal counts stay in group facts */
        if(vn[a].fi<0&&b<0){
            if(to<0)continue; /* unresolved site count is shown in group facts */
            if(section_of(&now.f[to])>=0){add_edge(a,b,-2-section_of(&now.f[to]),"",bind);continue;}
        }
        add_edge(a,b,to,to<0?target:"",bind);
    }
}
/* Text uses 7px cells at 12px. Tabs expand to four cells, LF is retained.
 * Long tokens wrap without dropping characters or inserting ellipses. */
static int text_lines(FILE *o,int x,int y,int width,const char *s,size_t length)
{
    char line[1024];size_t p=0,used=0;int cells=0,rows=0,col=0,cap=(width-32)/7;
    if(cap<8||cap>250)stop("text_capacity","");
#define FLUSH_LINE() do { if(o){fprintf(o,"<text x=\"%d\" y=\"%d\">",x,y+rows*18);xmln(o,line,used);fputs("</text>\n",o);}++rows;used=0;cells=0; } while(0)
    while(p<length){char chunk[8];int k=utf8_unit((const unsigned char *)s+p,length-p),units=1,parts=1,j;
        if(s[p]=='\n'){if(cells||!rows||p==0||s[p-1]=='\n'){FLUSH_LINE();}col=0;++p;continue;}
        if(s[p]=='\t'){parts=4-col%4;memset(chunk,' ',(size_t)parts);k=parts;++p;}
        else if(s[p]=='\r'){chunk[0]='\\';chunk[1]='r';parts=k=2;++p;}
        else if(!k){snprintf(chunk,sizeof(chunk),"\\x%02X",(unsigned char)s[p++]);parts=k=4;}
        else {memcpy(chunk,s+p,(size_t)k);p+=(size_t)k;units=k;}
        for(j=0;j<parts;++j){
            if(cells==cap){FLUSH_LINE();}
            memcpy(line+used,chunk+(parts==1?0:j),(size_t)units);used+=(size_t)units;++cells;++col;
            if(col>natural_width)natural_width=col;
        }
    }
    if(cells||!rows){FLUSH_LINE();}
#undef FLUSH_LINE
    return rows*18;
}
static int node_text(FILE *o,int n)
{
    ViewNode *v=&vn[n];int y=34,j,functions=0,inputs=0,returns=0,calls=0,unresolved=0,unreached=0;char buf[8192];
#define LINE(S) (y+=text_lines(o,v->x+16,v->y+y,v->w,(S),strlen(S)))
#define FORMAT(...) do { if(snprintf(buf,sizeof(buf),__VA_ARGS__)>=(int)sizeof(buf))stop("label_capacity",v->key);LINE(buf); } while(0)
    if(v->fi>=0){Function *f=&now.f[v->fi];Source *s=source(&now,f);
        FORMAT("%s | %s",f->home,f->name);
        FORMAT("source order %d | walk order %s",source_order(&now,f),now.r[f->at].v[2]);
        FORMAT("%s : lines %lu-%lu",f->file,(unsigned long)line_at(s,f->start),(unsigned long)line_at(s,f->end-1));
        FORMAT("closing } byte %lu | walk depth %d",(unsigned long)(f->end-1),f->depth);
        LINE("INPUTS (declared parameters)");
        for(j=f->first+1;j<f->last;++j){Record *r=&now.r[j];if(!strcmp(r->v[0],"IN")){size_t a=number(r->v[6]),b=number(r->v[7]);FORMAT("i%s | %s",r->v[2],r->v[3]);y+=text_lines(o,v->x+16,v->y+y,v->w,s->bytes+a,b-a);++inputs;}}
        if(!inputs)LINE("No declared parameters");
        LINE("INPUT ORIGINS / SUPPLIED ARGUMENTS");
        {int ci,found=0;for(ci=0;ci<now.nr;++ci){Record *r=&now.r[ci];int caller_index,k;Function *caller;
            if(strcmp(r->v[0],"CALL")||strcmp(r->v[4],f->id))continue;
            caller_index=find_function(&now,r->v[1]);caller=&now.f[caller_index];++found;
            FORMAT("[from: %s | %s]",caller->name,caller->home);
            FORMAT("%s | call byte %s",caller->file,r->v[2]);
            for(k=caller->first+1;k<caller->last;++k){Record *a=&now.r[k];if(!strcmp(a->v[0],"ARG")&&!strcmp(a->v[2],r->v[2])){FORMAT("i%s <=",a->v[3]);LINE(a->v[4]);}}
        }if(!found)LINE("No resolved direct caller collected");}
        {int bi,found=0;for(bi=0;bi<now.nr;++bi){Record *b=&now.r[bi];if(!strcmp(b->v[0],"BIND")&&!strcmp(b->v[3],f->id)){int pi=find_function(&now,b->v[1]);++found;FORMAT("PROVEN: %s | %s",now.f[pi].name,now.f[pi].home);FORMAT("return -> i%s | call byte %s",b->v[4],b->v[6]);}}if(inputs&&!found)LINE("Producer return link: review OPEN");}
        FORMAT("RETURN TYPE | %s",f->type);
        for(j=f->first+1;j<f->last;++j){Record *r=&now.r[j];if(!strcmp(r->v[0],"EFFECT")&&!strcmp(r->v[4],"return_site")){size_t a=number(r->v[2]),b=number(r->v[3]);FORMAT("return at line %lu / byte %lu",(unsigned long)line_at(s,a),(unsigned long)a);y+=text_lines(o,v->x+16,v->y+y,v->w,s->bytes+a,b-a);++returns;}}
        if(!returns)LINE("No explicit return statement collected");
        FORMAT("WRITE SITES | %d (exact evidence in XML)",count_records(&now,f,"EFFECT","write_site"));
        LINE("REVIEW | OPEN");
    }else{
        if(!strcmp(v->key,"OPEN"))LINE("OPEN | unassigned source functions");
        else if(strlen(v->key)==1)FORMAT("%s | %s",v->key,section_name(&now,v->key[0]-'A'));
        else FORMAT("%s | %s",v->key,now.sub[v->key[0]-'A'][v->key[1]-'a']?now.sub[v->key[0]-'A'][v->key[1]-'a']:"Logical role unassigned");
        LINE("Role label is reference; home is physical.");
        LINE("COVERAGE: full supplied registry");
        LINE("PATH REVIEW: OPEN");
        for(j=0;j<now.nf;++j)if(selected(&now.f[j],v->key)){Function *f=&now.f[j];int k;
            ++functions;inputs+=count_records(&now,f,"IN",NULL);returns+=count_records(&now,f,"EFFECT","return_site");calls+=count_records(&now,f,"CALL",NULL);if(f->depth<0)++unreached;
            for(k=f->first+1;k<f->last;++k)if(!strcmp(now.r[k].v[0],"CALL")&&now.r[k].v[4][0]=='?')++unresolved;
        }
        FORMAT("%d functions | %d parameters",functions,inputs);
        FORMAT("%d return sites | %d call sites",returns,calls);
        FORMAT("%d unresolved calls | %d outside main walk",unresolved,unreached);
        if(!functions)LINE("EMPTY PHYSICAL INVENTORY | review OPEN");
        else {
            LINE("DECLARED RETURN TYPES (exact spellings)");
            for(j=0;j<now.nf;++j)if(selected(&now.f[j],v->key)){int k,seen=0;for(k=0;k<j;++k)if(selected(&now.f[k],v->key)&&!strcmp(now.f[k].type,now.f[j].type)){seen=1;break;}if(!seen)LINE(now.f[j].type);}
            if(strlen(v->key)==1){int k;
                LINE("SUBSECTIONS (logical role / physical count)");
                for(k=0;k<26;++k){int count=0;for(j=0;j<now.nf;++j)if(selected(&now.f[j],v->key)&&now.f[j].home[1]=='a'+k)++count;
                    if(count||now.sub[v->key[0]-'A'][k])FORMAT("%c%c | %s | %d functions",v->key[0],'a'+k,now.sub[v->key[0]-'A'][k]?now.sub[v->key[0]-'A'][k]:"unassigned role",count);
                }
            }else{
                LINE("FUNCTIONS / SOURCE ACTION NAMES");
                for(j=0;j<now.nf;++j)if(selected(&now.f[j],v->key))FORMAT("%s | %s",now.f[j].home,now.f[j].name);
            }
        }
    }
    LINE("RELATIONSHIPS (site counts; full sites in XML)");
    for(j=0;j<ne;++j){ViewEdge *e=&ve[j];
        if(e->a==n){const char *name,*home;
            if(e->b>=0&&vn[e->b].fi<0){name=vn[e->b].key;home="group";}
            else if(e->target>=0){name=now.f[e->target].name;home=now.f[e->target].home;}
            else if(e->target<=-2){name=section_name(&now,-2-e->target);home="section group";}
            else {name=e->unknown;home="UNRESOLVED";}
            FORMAT("E%d | CALL %d | BIND %d",j+1,e->calls,e->binds);
            FORMAT("[to: %s | %s]",name,home);
            FORMAT("%s",e->direct?"centerline route":e->reason);
            if(o&&!strcmp(e->reason,"ownership bridge"))fprintf(o,"<circle cx=\"%d\" cy=\"%d\" r=\"5\" fill=\"white\" stroke=\"#2563eb\"/>\n",v->x,v->y+y-24);
        }
        if(e->b==n&&!strcmp(e->reason,"ownership bridge")){
            FORMAT("E%d | bridge from %s",j+1,vn[e->a].key);
            if(o)fprintf(o,"<circle cx=\"%d\" cy=\"%d\" r=\"5\" fill=\"white\" stroke=\"#2563eb\"/>\n",v->x,v->y+y-24);
        }
    }
    return y+12;
#undef FORMAT
#undef LINE
}
static int same_owner(int a,int b)
{
    /* A view of functions only routes within their exact Subsection. */
    return vn[a].fi>=0&&vn[b].fi>=0&&!strncmp(vn[a].key,vn[b].key,2);
}
static int intersects(int a,int b,int other)
{
    ViewNode *s=&vn[a],*t=&vn[b],*q=&vn[other];int x=s->x+s->w/2,y=s->y+s->h/2,u=t->x+t->w/2,v=t->y+t->h/2,lo,hi;
    if(x==u){lo=y<v?y:v;hi=y>v?y:v;return x>=q->x-8&&x<=q->x+q->w+8&&hi>q->y-8&&lo<q->y+q->h+8;}
    lo=x<u?x:u;hi=x>u?x:u;return y>=q->y-8&&y<=q->y+q->h+8&&hi>q->x-8&&lo<q->x+q->w+8;
}
static void geometry(void)
{
    int i,r,y=180;
    for(i=0;i<ne;++i){ViewEdge *e=&ve[i];e->reason=e->b<0?(e->target==-1?"unresolved target - review OPEN":"ownership bridge"):(e->a==e->b?"self-reference":(!same_owner(e->a,e->b)?"ownership bridge":"unaligned centers"));}
    for(i=0;i<nn;++i){static const int widths[]={240,256,288,320,360,384,427,480};int k=0;
        vn[i].w=480;vn[i].y=0;natural_width=0;(void)node_text(NULL,i);
        while(k<7&&widths[k]<natural_width*7+32)++k;
        vn[i].w=widths[k];vn[i].x=32+(i%3)*552+(480-vn[i].w)/2;
        vn[i].h=node_text(NULL,i);if(vn[i].h%2)++vn[i].h;
    }
    for(r=0;r<nn;r+=3){int h=0;for(i=r;i<r+3&&i<nn;++i)if(vn[i].h>h)h=vn[i].h;for(i=r;i<r+3&&i<nn;++i)vn[i].y=y+(h-vn[i].h)/2;y+=h+72;}
    for(i=0;i<ne;++i){ViewEdge *e=&ve[i];ViewNode *a,*b;int j,blocked=0;
        if(strcmp(e->reason,"unaligned centers"))continue;
        a=&vn[e->a];b=&vn[e->b];
        if(a->x+a->w/2!=b->x+b->w/2&&a->y+a->h/2!=b->y+b->h/2)continue;
        for(j=0;j<nn;++j)if(j!=e->a&&j!=e->b&&intersects(e->a,e->b,j)){blocked=1;break;}
        if(blocked){e->reason="blocked corridor";continue;}
        /* A reverse pair would occupy the same corridor. */
        for(j=0;j<i;++j)if(ve[j].direct&&ve[j].a==e->b&&ve[j].b==e->a)blocked=1;
        if(blocked){e->reason="occupied corridor";continue;}
        e->direct=1;
    }
}
static void draw_view(const char *relative,const char *scope)
{
    FILE *o;int i,height=260;view_model(scope);geometry();
    for(i=0;i<nn;++i)if(vn[i].y+vn[i].h+40>height)height=vn[i].y+vn[i].h+40;
    o=newfile(relative);fprintf(o,"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"1656\" height=\"%d\" viewBox=\"0 0 1656 %d\">\n",height,height);
    fputs("<style>text{font:12px monospace;fill:#17233a;white-space:pre} .heading{font:bold 24px monospace}</style>\n<defs><marker id=\"arrow\" markerWidth=\"10\" markerHeight=\"8\" refX=\"9\" refY=\"4\" orient=\"auto\"><path d=\"M1 1 L9 4 L1 7\" fill=\"none\" stroke=\"#2563eb\"/></marker></defs>\n",o);
    fputs("<defs>\n",o);for(i=0;i<nn;++i)fprintf(o,"<marker id=\"arrow-%d\" markerWidth=\"10\" markerHeight=\"8\" refX=\"9\" refY=\"4\" orient=\"auto\"><path d=\"M1 1 L9 4 L1 7\" fill=\"none\" stroke=\"%s\"/></marker>\n",i,node_color(i));fputs("</defs>\n",o);
    fprintf(o,"<rect width=\"1656\" height=\"%d\" fill=\"#f1f5fa\"/>\n<text class=\"heading\" x=\"32\" y=\"38\">",height);xml(o,scope);fputs(" | SOURCE WALK</text>\n<text x=\"32\" y=\"65\">SOURCE ",o);xml(o,now.revision);fputs(" | REVIEW OPEN</text>\n<text x=\"32\" y=\"88\">CALL = source call sites. BIND = proven nested return to parameter; other data flow remains unproven.</text>\n<text x=\"32\" y=\"110\">Circle = ownership bridge; matching E IDs pair endpoints. Triangle = declared bool/_Bool marker.</text>\n<text x=\"32\" y=\"132\">Notes and counts are generated from source evidence. No endpoint or correctness claim is inferred.</text>\n<text x=\"32\" y=\"154\">Exact parameters, returns, write sites and closing braces are retained in the matching XML.</text>\n",o);
    if(!nn)fputs("<text x=\"32\" y=\"208\">No physical functions or logical subsections in this export. Inventory review remains OPEN.</text>\n",o);
    for(i=0;i<ne;++i)if(ve[i].direct){ViewNode *a=&vn[ve[i].a],*b=&vn[ve[i].b];int x=a->x+a->w/2,y=a->y+a->h/2,u=b->x+b->w/2,v=b->y+b->h/2;
        if(x==u){if(v>y){y=a->y+a->h;v=b->y;}else {y=a->y;v=b->y+b->h;}}
        else if(u>x){x=a->x+a->w;u=b->x;}else {x=a->x;u=b->x+b->w;}
        fprintf(o,"<g id=\"E%d\"><path d=\"M%d %d L%d %d\" fill=\"none\" stroke=\"%s\" stroke-width=\"2\" marker-end=\"url(#arrow-%d)\"/><text x=\"%d\" y=\"%d\">E%d</text></g>\n",i+1,x,y,u,v,node_color(ve[i].a),ve[i].a,(x+u)/2+8,(y+v)/2-8,i+1);
    }
    for(i=0;i<nn;++i){ViewNode *v=&vn[i];fprintf(o,"<g id=\"node-%d\"><rect x=\"%d\" y=\"%d\" width=\"%d\" height=\"%d\" rx=\"6\" fill=\"white\" stroke=\"#72859e\"/>\n",i,v->x,v->y,v->w,v->h);
        fprintf(o,"<path d=\"M%d %d h%d\" stroke=\"%s\" stroke-width=\"6\"/>\n",v->x+6,v->y+3,v->w-12,node_color(i));
        if(v->fi>=0&&(!strcmp(now.f[v->fi].type,"bool")||!strcmp(now.f[v->fi].type,"_Bool")))fprintf(o,"<path d=\"M%d %d l12 -20 l12 20 z\" fill=\"#e0edff\" stroke=\"#2563eb\"/>\n",v->x+v->w-30,v->y-4);
        if(node_text(o,i)>v->h)stop("layout_measurement",v->key);
        fputs("</g>\n",o);
    }
    fputs("</svg>\n",o);closeout(o);
}
static void finding(FILE *o,const char *kind,Function *f,const char *byte,const char *evidence)
{
    fputs("<item state=\"OPEN\" kind=\"",o);xml(o,kind);fputs("\" identity=\"",o);xml(o,f->id);fputs("\" address=\"",o);xml(o,f->home);fputs("\" byte=\"",o);xml(o,byte);fputs("\"><evidence>",o);xml(o,evidence);fputs("</evidence><assignment>UNASSIGNED</assignment></item>\n",o);
}
static void write_findings(void)
{
    FILE *o=newfile("review_queue.xml");int i,j,unresolved=0,unreached=0,unhomed=0,no_return=0;
    fputs("<review_queue source_revision=\"",o);xml(o,now.revision);fputs("\">\n<meaning>Mechanical review candidates, not confirmed bugs. Scope and reachability depend on collector coverage. No agents assigned.</meaning>\n",o);
    for(i=0;i<now.nf;++i){Function *f=&now.f[i];char pos[32];snprintf(pos,sizeof(pos),"%lu",(unsigned long)(f->end-1));
        if(f->depth<0){++unreached;finding(o,"OUTSIDE_MAIN_WALK",f,pos,"Not reached by the exported static main walk; callbacks and other entries need review.");}
        if(section_of(f)<0){++unhomed;finding(o,"NO_ISSUED_HOME",f,pos,"No issued physical home in this export.");}
        if(strcmp(f->type,"void")&&!count_records(&now,f,"EFFECT","return_site")){++no_return;finding(o,"NO_EXPLICIT_RETURN_SITE",f,pos,"Non-void declared return channel has no collected explicit return. Review control flow and macros.");}
        for(j=f->first+1;j<f->last;++j){Record *r=&now.r[j];if(!strcmp(r->v[0],"CALL")&&r->v[4][0]=='?'){++unresolved;finding(o,"UNRESOLVED_CALL",f,r->v[2],r->v[4]);}}
    }
    fprintf(o,"<counts unresolved_calls=\"%d\" outside_main_walk=\"%d\" unhomed_functions=\"%d\" no_explicit_return=\"%d\"/>\n</review_queue>\n",unresolved,unreached,unhomed,no_return);closeout(o);
    o=newfile("BUILD_REPORT.txt");fprintf(o,"AUTOMATIC SOURCE-WALK VIEWS\nSource revision: %s\nFunctions: %d | files: %d\n\nSECTION-A through SECTION-O use an em dash in their directory names.\nEach section has one function.xml, section.txt, exact source copies and selected SVGs.\nSubsections remain logical keys inside the flat section; no subsection directories.\nUNASSIGNED-SOURCE retains files without an issued function home.\nClosing brace is end-exclusive minus one, verified against source bytes.\nActual declared return types and all collected return statements are retained.\nInputs include caller names, arguments and proven nested-return producers.\nFunction order preserves source-file order, registry order and walk order separately.\nCALL sites and proven nested-return BIND sites are different relationships.\nFunction diff uses file#name and exact canonical evidence; no prior means baseline-only.\nReview queue: %d unresolved call sites, %d outside main walk, %d unhomed,\n%d non-void functions with no collected explicit return. These are candidates, not bugs.\n\nCollector coverage governs these views; callbacks, macros, indirect calls and\nexecution paths retain OPEN review status. Logical roles remain separate from homes.\nGroup views aggregate edges by destination; sites remain exact in XML.\n",now.revision,now.nf,now.ns,unresolved,unreached,unhomed,no_return);closeout(o);
}
